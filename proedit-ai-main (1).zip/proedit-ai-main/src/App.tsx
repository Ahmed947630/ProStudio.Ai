import { useEffect } from "react";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, useLocation } from "react-router-dom";
import { AuthProvider } from "@/contexts/AuthContext";
import ProtectedRoute from "@/components/ProtectedRoute";
import { initAdMob, onPageSwitch } from "@/lib/admob";
import Index from "./pages/Index";
import NotFound from "./pages/NotFound";
import Auth from "./pages/Auth";
import HeadshotGenerator from "./pages/HeadshotGenerator";
import ProductPhotoshoot from "./pages/ProductPhotoshoot";
import OutfitChanger from "./pages/OutfitChanger";
import Upscaler from "./pages/Upscaler";
import AiExpand from "./pages/AiExpand";
import MagicEraser from "./pages/MagicEraser";
import Profile from "./pages/Profile";
import PrivacyPolicy from "./pages/PrivacyPolicy";
import TermsOfService from "./pages/TermsOfService";

const queryClient = new QueryClient();

// Component to track page switches and show interstitial ads
const InterstitialAdTrigger = () => {
  const location = useLocation();

  useEffect(() => {
    onPageSwitch();
  }, [location.pathname]);

  return null;
};

const App = () => {
  useEffect(() => {
    initAdMob();
  }, []);

  return (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <AuthProvider>
          <InterstitialAdTrigger />
          <Routes>
            <Route path="/" element={<Index />} />
            <Route path="/auth" element={<Auth />} />
            <Route path="/profile" element={<ProtectedRoute><Profile /></ProtectedRoute>} />
            <Route path="/headshot" element={<ProtectedRoute><HeadshotGenerator /></ProtectedRoute>} />
            <Route path="/product" element={<ProtectedRoute><ProductPhotoshoot /></ProtectedRoute>} />
            <Route path="/outfit" element={<ProtectedRoute><OutfitChanger /></ProtectedRoute>} />
            <Route path="/upscale" element={<ProtectedRoute><Upscaler /></ProtectedRoute>} />
            <Route path="/expand" element={<ProtectedRoute><AiExpand /></ProtectedRoute>} />
            <Route path="/eraser" element={<ProtectedRoute><MagicEraser /></ProtectedRoute>} />
            <Route path="/privacy" element={<PrivacyPolicy />} />
            <Route path="/terms" element={<TermsOfService />} />
            <Route path="*" element={<NotFound />} />
          </Routes>
        </AuthProvider>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
  );
};

export default App;
