import { AdMob, AdLoadInfo, RewardAdOptions, AdMobRewardItem, RewardAdPluginEvents, InterstitialAdPluginEvents, AdOptions } from '@capacitor-community/admob';

// Real Ad Unit IDs from AdMob console
const REWARDED_AD_ID_ANDROID = 'ca-app-pub-3560957338308574/6641681224';
const REWARDED_AD_ID_IOS = 'ca-app-pub-3560957338308574/5923641719';
const INTERSTITIAL_AD_ID = 'ca-app-pub-3560957338308574/5923641719';

let initialized = false;
let pageViewCount = 0;
const INTERSTITIAL_EVERY_N_PAGES = 3; // Show interstitial every 3 page switches

export const isNativeApp = (): boolean => {
  return typeof (window as any)?.Capacitor !== 'undefined' && (window as any)?.Capacitor?.isNativePlatform?.();
};

export const initAdMob = async (): Promise<void> => {
  if (initialized || !isNativeApp()) return;
  
  try {
    await AdMob.initialize({
      initializeForTesting: false,
    });
    initialized = true;
    console.log('AdMob initialized successfully');
  } catch (error) {
    console.error('AdMob initialization failed:', error);
  }
};

// Interstitial ad logic
export const showInterstitialAd = async (): Promise<void> => {
  if (!isNativeApp()) return;

  try {
    if (!initialized) await initAdMob();

    const options: AdOptions = {
      adId: INTERSTITIAL_AD_ID,
      isTesting: false,
    };

    await AdMob.prepareInterstitial(options);
    await AdMob.showInterstitial();
  } catch (error) {
    console.error('Interstitial ad error:', error);
  }
};

// Call this on every page navigation; shows ad every N pages
export const onPageSwitch = (): void => {
  pageViewCount++;
  if (pageViewCount >= INTERSTITIAL_EVERY_N_PAGES) {
    pageViewCount = 0;
    showInterstitialAd();
  }
};

export const showRewardedAd = (): Promise<boolean> => {
  return new Promise(async (resolve) => {
    if (!isNativeApp()) {
      resolve(false);
      return;
    }

    try {
      if (!initialized) await initAdMob();

      const platform = (window as any)?.Capacitor?.getPlatform?.();
      const adId = platform === 'ios' ? REWARDED_AD_ID_IOS : REWARDED_AD_ID_ANDROID;

      const options: RewardAdOptions = {
        adId,
        isTesting: false,
      };

      let rewarded = false;

      const rewardListener = await AdMob.addListener(
        RewardAdPluginEvents.Rewarded,
        (reward: AdMobRewardItem) => {
          console.log('User earned reward:', reward);
          rewarded = true;
        }
      );

      const dismissListener = await AdMob.addListener(
        RewardAdPluginEvents.Dismissed,
        () => {
          rewardListener.remove();
          dismissListener.remove();
          failListener.remove();
          setTimeout(() => resolve(rewarded), 300);
        }
      );

      const failListener = await AdMob.addListener(
        RewardAdPluginEvents.FailedToLoad,
        (error: any) => {
          console.error('Rewarded ad failed to load:', error);
          rewardListener.remove();
          dismissListener.remove();
          failListener.remove();
          resolve(false);
        }
      );

      await AdMob.prepareRewardVideoAd(options);
      await AdMob.showRewardVideoAd();
    } catch (error) {
      console.error('Error showing rewarded ad:', error);
      resolve(false);
    }
  });
};
