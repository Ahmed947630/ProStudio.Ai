import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { Sparkles } from "lucide-react";
import { Progress } from "@/components/ui/progress";

interface ProcessingScreenProps {
  onComplete: () => void;
  label?: string;
  duration?: number;
}

const ProcessingScreen = ({ onComplete, label = "AI is working its magic...", duration = 4000 }: ProcessingScreenProps) => {
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          setTimeout(onComplete, 300);
          return 100;
        }
        return prev + 2;
      });
    }, duration / 50);
    return () => clearInterval(interval);
  }, [onComplete, duration]);

  const steps = [
    "Analyzing facial features...",
    "Generating professional background...",
    "Applying studio lighting...",
    "Fine-tuning details...",
    "Finalizing output...",
  ];

  const currentStep = Math.min(Math.floor(progress / 20), steps.length - 1);

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      className="flex flex-col items-center justify-center py-16 gap-8"
    >
      <div className="relative">
        <div className="h-24 w-24 rounded-full bg-primary/10 flex items-center justify-center">
          <Sparkles className="h-10 w-10 text-primary animate-pulse-gold" />
        </div>
        <div className="absolute inset-0 rounded-full border-2 border-primary/30 animate-ping" />
      </div>

      <div className="text-center space-y-2">
        <h3 className="font-display text-2xl font-bold">{label}</h3>
        <p className="text-muted-foreground text-sm">{steps[currentStep]}</p>
      </div>

      <div className="w-full max-w-sm space-y-2">
        <Progress value={progress} className="h-2 bg-secondary [&>div]:bg-gradient-gold" />
        <p className="text-center text-sm text-muted-foreground">{Math.round(progress)}%</p>
      </div>
    </motion.div>
  );
};

export default ProcessingScreen;
