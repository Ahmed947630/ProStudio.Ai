import React from "react";
import { ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
import Logo from "@/components/Logo";

interface FeatureLayoutProps {
  title: string;
  subtitle: string;
  children: React.ReactNode;
}

const FeatureLayout = React.forwardRef<HTMLDivElement, FeatureLayoutProps>(
  ({ title, subtitle, children }, ref) => {
    const navigate = useNavigate();

    return (
      <div ref={ref} className="min-h-screen bg-background">
        <nav className="fixed top-0 z-50 w-full border-b border-border/50 bg-background/80 backdrop-blur-xl safe-top">
          <div className="container mx-auto flex h-14 items-center justify-between px-4">
            <Logo size="sm" />
            <Button variant="ghost" size="sm" onClick={() => navigate(-1 as any)} className="gap-2 touch-target">
              <ArrowLeft className="h-4 w-4" /> Back
            </Button>
          </div>
        </nav>

        <div className="pt-20 pb-16 px-4 safe-top safe-bottom">
          <div className="container mx-auto max-w-4xl">
            <div className="text-center mb-8">
              <h1 className="font-display text-3xl md:text-5xl font-bold mb-2">{title}</h1>
              <p className="text-muted-foreground text-base max-w-xl mx-auto">{subtitle}</p>
            </div>
            {children}
          </div>
        </div>
      </div>
    );
  }
);

FeatureLayout.displayName = "FeatureLayout";

export default FeatureLayout;
