import logoImage from "@/assets/logo.jpg";
import { useNavigate } from "react-router-dom";

interface LogoProps {
  size?: "sm" | "md" | "lg";
  clickable?: boolean;
}

const Logo = ({ size = "md", clickable = true }: LogoProps) => {
  const navigate = useNavigate();
  
  const sizeClasses = {
    sm: "h-8 w-8",
    md: "h-10 w-10",
    lg: "h-16 w-16",
  };

  const textClasses = {
    sm: "text-lg",
    md: "text-xl",
    lg: "text-2xl",
  };

  const content = (
    <div className="flex items-center gap-2.5">
      <img
        src={logoImage}
        alt="ProStudio AI logo"
        className={`${sizeClasses[size]} rounded-xl object-cover`}
      />
      <span className={`font-display ${textClasses[size]} font-bold tracking-tight`}>
        pro studio<span className="text-gradient-gold">.Ai</span>
      </span>
    </div>
  );

  if (clickable) {
    return (
      <button onClick={() => navigate("/")} className="hover:opacity-80 transition-opacity">
        {content}
      </button>
    );
  }

  return content;
};

export default Logo;
