import { useState, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Play, X, Timer, CheckCircle2, Smartphone, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { showRewardedAd, isNativeApp } from "@/lib/admob";

const SINGLE_AD_DURATION = 15;

interface AdGateModalProps {
  open: boolean;
  onClose: () => void;
  onComplete: () => void;
  adCount?: number;
  title?: string;
  subtitle?: string;
}

const AdGateModal = ({ open, onClose, onComplete, adCount = 1, title, subtitle }: AdGateModalProps) => {
  const [currentAd, setCurrentAd] = useState(1);
  const [timer, setTimer] = useState(SINGLE_AD_DURATION);
  const [watching, setWatching] = useState(false);
  const [allDone, setAllDone] = useState(false);
  const [loadingAd, setLoadingAd] = useState(false);
  const native = isNativeApp();

  useEffect(() => {
    if (open) {
      setCurrentAd(1);
      setTimer(SINGLE_AD_DURATION);
      setWatching(false);
      setAllDone(false);
      setLoadingAd(false);
    }
  }, [open]);

  // Fallback timer for web
  useEffect(() => {
    if (!watching || timer <= 0 || native) return;
    const interval = setInterval(() => {
      setTimer((t) => {
        if (t <= 1) { clearInterval(interval); return 0; }
        return t - 1;
      });
    }, 1000);
    return () => clearInterval(interval);
  }, [watching, timer, native]);

  useEffect(() => {
    if (timer === 0 && watching && !native) {
      setWatching(false);
      if (currentAd >= adCount) setAllDone(true);
    }
  }, [timer, watching, currentAd, adCount, native]);

  const showNativeAd = async () => {
    setLoadingAd(true);
    const rewarded = await showRewardedAd();
    setLoadingAd(false);
    
    if (rewarded) {
      if (currentAd >= adCount) {
        setAllDone(true);
      } else {
        setCurrentAd((c) => c + 1);
      }
    }
    // If not rewarded (dismissed/failed), user stays on same state
  };

  const handleStartAd = () => {
    if (native) {
      showNativeAd();
    } else {
      setWatching(true);
      setTimer(SINGLE_AD_DURATION);
    }
  };

  const handleNextAd = () => {
    if (native) {
      showNativeAd();
    } else {
      setCurrentAd((c) => c + 1);
      setTimer(SINGLE_AD_DURATION);
      setWatching(true);
    }
  };

  const handleComplete = useCallback(() => {
    setAllDone(false);
    onComplete();
  }, [onComplete]);

  const handleClose = () => {
    if (watching || loadingAd) return;
    setWatching(false);
    setAllDone(false);
    onClose();
  };

  if (!open) return null;

  const adFinished = !native && timer === 0 && !watching;
  const showNextButton = native ? !allDone && currentAd > 1 && currentAd <= adCount : adFinished && !allDone && !watching;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-[100] flex items-center justify-center bg-background/80 backdrop-blur-md p-4"
        onClick={(e) => e.target === e.currentTarget && !watching && !loadingAd && handleClose()}
      >
        <motion.div
          initial={{ opacity: 0, scale: 0.9, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.9, y: 20 }}
          className="relative w-full max-w-md rounded-2xl border border-border bg-card overflow-hidden shadow-2xl"
        >
          {/* Close button */}
          {!watching && !allDone && !loadingAd && (
            <button onClick={handleClose} className="absolute top-4 right-4 z-10 text-muted-foreground hover:text-foreground transition-colors">
              <X className="h-5 w-5" />
            </button>
          )}

          {/* Loading Ad State */}
          {loadingAd && (
            <div className="p-8 text-center">
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ repeat: Infinity, duration: 1, ease: "linear" }}
                className="mx-auto mb-4 w-16 h-16 flex items-center justify-center"
              >
                <Loader2 className="h-10 w-10 text-primary" />
              </motion.div>
              <h3 className="font-display text-lg font-bold mb-1">Loading Ad...</h3>
              <p className="text-sm text-muted-foreground">Please wait while the video ad loads</p>
            </div>
          )}

          {/* All ads complete */}
          {allDone && !loadingAd && (
            <div className="p-8 text-center">
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ type: "spring", stiffness: 200 }}
                className="mx-auto mb-4 w-20 h-20 rounded-full bg-primary/20 flex items-center justify-center"
              >
                <CheckCircle2 className="h-10 w-10 text-primary" />
              </motion.div>
              <h3 className="font-display text-xl font-bold mb-2">🎉 All Done!</h3>
              <p className="text-muted-foreground text-sm mb-6">
                {adCount > 1 ? "All ads watched! Your download is ready." : "Ad complete! You can now proceed."}
              </p>
              <Button onClick={handleComplete} className="w-full h-12 rounded-xl bg-primary text-primary-foreground font-bold text-base">
                {adCount > 1 ? "Download Now" : "Continue"}
              </Button>
            </div>
          )}

          {/* Watching ad (web fallback only) */}
          {watching && !native && !loadingAd && (
            <div className="p-6">
              <div className="text-center">
                {adCount > 1 && (
                  <div className="flex items-center justify-center gap-2 mb-4">
                    {Array.from({ length: adCount }).map((_, i) => (
                      <div
                        key={i}
                        className={`h-2 rounded-full transition-all duration-300 ${
                          i + 1 < currentAd ? "w-8 bg-primary" : i + 1 === currentAd ? "w-8 bg-primary/60" : "w-2 bg-muted"
                        }`}
                      />
                    ))}
                  </div>
                )}

                <div className="relative mx-auto mb-4 w-20 h-20">
                  <svg className="w-20 h-20 -rotate-90" viewBox="0 0 80 80">
                    <circle cx="40" cy="40" r="36" fill="none" stroke="hsl(var(--muted))" strokeWidth="4" />
                    <circle
                      cx="40" cy="40" r="36" fill="none"
                      stroke="hsl(var(--primary))"
                      strokeWidth="4"
                      strokeLinecap="round"
                      strokeDasharray={`${2 * Math.PI * 36}`}
                      strokeDashoffset={`${2 * Math.PI * 36 * (timer / SINGLE_AD_DURATION)}`}
                      className="transition-all duration-1000 ease-linear"
                    />
                  </svg>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <span className="font-display text-2xl font-bold text-primary">{timer}</span>
                  </div>
                </div>
                <h3 className="font-display text-lg font-bold mb-1">
                  {adCount > 1 ? `Ad ${currentAd} of ${adCount}` : "Watching Ad..."}
                </h3>
                <p className="text-sm text-muted-foreground">Please wait {timer}s</p>

                <div className="mt-4 rounded-xl bg-muted/50 border border-border p-8 flex flex-col items-center justify-center min-h-[180px]">
                  <div className="flex items-center gap-2 text-muted-foreground mb-2">
                    <Play className="h-5 w-5" />
                    <span className="text-sm font-medium">Advertisement</span>
                  </div>
                  <div className="w-full bg-muted rounded-full h-1.5 mt-4">
                    <div
                      className="bg-primary h-1.5 rounded-full transition-all duration-1000 ease-linear"
                      style={{ width: `${((SINGLE_AD_DURATION - timer) / SINGLE_AD_DURATION) * 100}%` }}
                    />
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Ad finished but more to go (web fallback) */}
          {!native && adFinished && !allDone && !watching && !loadingAd && (
            <div className="p-6 text-center">
              {adCount > 1 && (
                <div className="flex items-center justify-center gap-2 mb-4">
                  {Array.from({ length: adCount }).map((_, i) => (
                    <div
                      key={i}
                      className={`h-2 rounded-full transition-all duration-300 ${
                        i + 1 <= currentAd ? "w-8 bg-primary" : "w-2 bg-muted"
                      }`}
                    />
                  ))}
                </div>
              )}
              <motion.div
                initial={{ scale: 0.8 }}
                animate={{ scale: 1 }}
                className="mx-auto mb-4 w-16 h-16 rounded-full bg-primary/20 flex items-center justify-center"
              >
                <CheckCircle2 className="h-8 w-8 text-primary" />
              </motion.div>
              <h3 className="font-display text-lg font-bold mb-2">Ad {currentAd} Complete!</h3>
              <p className="text-muted-foreground text-sm mb-4">
                {adCount - currentAd} more ad{adCount - currentAd > 1 ? "s" : ""} remaining
              </p>
              <Button onClick={handleNextAd} className="w-full h-12 rounded-xl bg-primary text-primary-foreground font-bold text-base gap-2">
                <Play className="h-4 w-4" /> Watch Next Ad
              </Button>
            </div>
          )}

          {/* Initial state */}
          {!watching && !adFinished && !allDone && !loadingAd && (
            <div className="p-6 text-center">
              <div className="mx-auto mb-4 w-16 h-16 rounded-2xl bg-primary/20 flex items-center justify-center">
                {native ? <Smartphone className="h-8 w-8 text-primary" /> : <Play className="h-8 w-8 text-primary" />}
              </div>
              <h2 className="font-display text-2xl font-bold mb-1">
                {title || (adCount > 1 ? "Watch 3 Ads to Download" : "Watch Ad to Continue")}
              </h2>
              <p className="text-muted-foreground text-sm mb-6">
                {subtitle || (adCount > 1
                  ? `Watch ${adCount} short video ads to unlock your download`
                  : "Watch a short video ad to use this premium tool")}
              </p>
              
              {/* Progress for multi-ad (native) */}
              {native && adCount > 1 && (
                <div className="flex items-center justify-center gap-2 mb-4">
                  {Array.from({ length: adCount }).map((_, i) => (
                    <div
                      key={i}
                      className={`h-2 rounded-full transition-all duration-300 ${
                        i + 1 < currentAd ? "w-8 bg-primary" : "w-2 bg-muted"
                      }`}
                    />
                  ))}
                </div>
              )}

              <Button onClick={handleStartAd} className="w-full h-12 rounded-xl bg-primary text-primary-foreground font-bold text-base gap-2">
                <Play className="h-4 w-4" />
                {native ? "Watch Video Ad" : "Start Watching"}
              </Button>
              {!native && (
                <p className="text-xs text-muted-foreground mt-3 flex items-center justify-center gap-1">
                  <Timer className="h-3 w-3" /> {adCount * SINGLE_AD_DURATION}s total
                </p>
              )}
            </div>
          )}
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
};

export default AdGateModal;
