import React, { useCallback, useState } from "react";
import { Upload, Image as ImageIcon } from "lucide-react";

interface UploadZoneProps {
  onFileSelect: (files: File[]) => void;
  accept?: string;
  multiple?: boolean;
  label?: string;
  sublabel?: string;
}

const UploadZone = React.forwardRef<HTMLLabelElement, UploadZoneProps>(
  ({ onFileSelect, accept = "image/*", multiple = false, label = "Drop your photo here", sublabel = "or click to browse" }, ref) => {
    const [dragOver, setDragOver] = useState(false);

    const handleDrop = useCallback((e: React.DragEvent) => {
      e.preventDefault();
      setDragOver(false);
      const files = Array.from(e.dataTransfer.files).filter(f => f.type.startsWith("image/"));
      if (files.length) onFileSelect(files);
    }, [onFileSelect]);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      const files = Array.from(e.target.files || []);
      if (files.length) onFileSelect(files);
    };

    return (
      <label
        ref={ref}
        onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
        onDragLeave={() => setDragOver(false)}
        onDrop={handleDrop}
        className={`relative flex flex-col items-center justify-center w-full h-64 rounded-2xl border-2 border-dashed cursor-pointer transition-all duration-300 ${
          dragOver
            ? "border-primary bg-primary/10 scale-[1.02]"
            : "border-border hover:border-primary/40 hover:bg-card"
        }`}
      >
        <input type="file" accept={accept} multiple={multiple} onChange={handleChange} className="hidden" />
        <div className="flex flex-col items-center gap-3">
          <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-primary/10 text-primary">
            {dragOver ? <ImageIcon className="h-8 w-8" /> : <Upload className="h-8 w-8" />}
          </div>
          <div className="text-center">
            <p className="font-display text-lg font-semibold">{label}</p>
            <p className="text-sm text-muted-foreground">{sublabel}</p>
          </div>
        </div>
      </label>
    );
  }
);

UploadZone.displayName = "UploadZone";

export default UploadZone;
