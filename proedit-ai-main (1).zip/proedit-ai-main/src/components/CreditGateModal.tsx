import { useState, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Crown, Play, X, Zap, Gift, ShieldCheck, Sparkles, Timer } from "lucide-react";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "sonner";

interface CreditGateModalProps {
  open: boolean;
  onClose: () => void;
  onCreditsAdded?: () => void;
}

const AD_DURATION = 15; // seconds to "watch" ad

const CreditGateModal = ({ open, onClose, onCreditsAdded }: CreditGateModalProps) => {
  const { user } = useAuth();
  const [watchingAd, setWatchingAd] = useState(false);
  const [adTimer, setAdTimer] = useState(AD_DURATION);
  const [adComplete, setAdComplete] = useState(false);

  // Ad timer countdown
  useEffect(() => {
    if (!watchingAd || adTimer <= 0) return;
    const interval = setInterval(() => {
      setAdTimer((t) => {
        if (t <= 1) {
          clearInterval(interval);
          setAdComplete(true);
          setWatchingAd(false);
          return 0;
        }
        return t - 1;
      });
    }, 1000);
    return () => clearInterval(interval);
  }, [watchingAd, adTimer]);

  const handleWatchAd = () => {
    setWatchingAd(true);
    setAdTimer(AD_DURATION);
    setAdComplete(false);
  };

  const handleClaimReward = useCallback(async () => {
    if (!user) return;
    const { error } = await supabase
      .from("profiles")
      .update({ credits: 1 })
      .eq("user_id", user.id);

    if (error) {
      toast.error("Failed to add credits");
      return;
    }
    toast.success("🎉 +1 credit added!");
    setAdComplete(false);
    onCreditsAdded?.();
    onClose();
  }, [user, onCreditsAdded, onClose]);

  const handleClose = () => {
    setWatchingAd(false);
    setAdTimer(AD_DURATION);
    setAdComplete(false);
    onClose();
  };

  if (!open) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-[100] flex items-center justify-center bg-background/80 backdrop-blur-md p-4"
        onClick={(e) => e.target === e.currentTarget && !watchingAd && handleClose()}
      >
        <motion.div
          initial={{ opacity: 0, scale: 0.9, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.9, y: 20 }}
          className="relative w-full max-w-md rounded-2xl border border-border bg-card overflow-hidden shadow-2xl"
        >
          {/* Close button */}
          {!watchingAd && (
            <button onClick={handleClose} className="absolute top-4 right-4 z-10 text-muted-foreground hover:text-foreground transition-colors">
              <X className="h-5 w-5" />
            </button>
          )}

          {/* Watching Ad Screen */}
          {watchingAd && !adComplete && (
            <div className="p-6">
              <div className="text-center">
                <div className="relative mx-auto mb-4 w-20 h-20">
                  <svg className="w-20 h-20 -rotate-90" viewBox="0 0 80 80">
                    <circle cx="40" cy="40" r="36" fill="none" stroke="hsl(var(--muted))" strokeWidth="4" />
                    <circle
                      cx="40" cy="40" r="36" fill="none"
                      stroke="hsl(var(--primary))"
                      strokeWidth="4"
                      strokeLinecap="round"
                      strokeDasharray={`${2 * Math.PI * 36}`}
                      strokeDashoffset={`${2 * Math.PI * 36 * (adTimer / AD_DURATION)}`}
                      className="transition-all duration-1000 ease-linear"
                    />
                  </svg>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <span className="font-display text-2xl font-bold text-primary">{adTimer}</span>
                  </div>
                </div>
                <h3 className="font-display text-lg font-bold mb-1">Watching Ad...</h3>
                <p className="text-sm text-muted-foreground">Please wait {adTimer}s to earn your free credit</p>

                {/* Simulated Ad Area */}
                <div className="mt-4 rounded-xl bg-muted/50 border border-border p-8 flex flex-col items-center justify-center min-h-[180px]">
                  <div className="flex items-center gap-2 text-muted-foreground mb-2">
                    <Play className="h-5 w-5" />
                    <span className="text-sm font-medium">Advertisement</span>
                  </div>
                  <div className="w-full bg-muted rounded-full h-1.5 mt-4">
                    <div
                      className="bg-primary h-1.5 rounded-full transition-all duration-1000 ease-linear"
                      style={{ width: `${((AD_DURATION - adTimer) / AD_DURATION) * 100}%` }}
                    />
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Ad Complete - Claim Reward */}
          {adComplete && (
            <div className="p-6 text-center">
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ type: "spring", stiffness: 200 }}
                className="mx-auto mb-4 w-20 h-20 rounded-full bg-primary/20 flex items-center justify-center"
              >
                <Gift className="h-10 w-10 text-primary" />
              </motion.div>
              <h3 className="font-display text-xl font-bold mb-2">🎉 Ad Complete!</h3>
              <p className="text-muted-foreground text-sm mb-6">Tap below to claim your free credit</p>
              <Button onClick={handleClaimReward} className="w-full h-12 rounded-xl bg-primary text-primary-foreground font-bold text-base">
                <Zap className="h-4 w-4 mr-2" /> Claim +1 Credit
              </Button>
            </div>
          )}

          {/* Main Gate Screen */}
          {!watchingAd && !adComplete && (
            <>
              {/* Header */}
              <div className="relative px-6 pt-8 pb-4 text-center bg-gradient-to-b from-primary/10 to-transparent">
                <div className="mx-auto mb-3 w-16 h-16 rounded-2xl bg-primary/20 flex items-center justify-center">
                  <Crown className="h-8 w-8 text-primary" />
                </div>
                <h2 className="font-display text-2xl font-bold mb-1">Credits Finished!</h2>
                <p className="text-muted-foreground text-sm">Watch an ad or upgrade to keep creating</p>
              </div>

              {/* Options */}
              <div className="p-6 space-y-3">
                {/* Watch Ad Option */}
                <button
                  onClick={handleWatchAd}
                  className="w-full flex items-center gap-4 p-4 rounded-xl border border-border bg-muted/30 hover:border-primary/40 hover:bg-muted/60 transition-all group text-left"
                >
                  <div className="flex-shrink-0 h-12 w-12 rounded-xl bg-accent/20 flex items-center justify-center text-accent group-hover:scale-110 transition-transform">
                    <Play className="h-6 w-6" />
                  </div>
                  <div className="flex-1">
                    <p className="font-semibold text-sm">Watch Ad — Free Credit</p>
                    <p className="text-xs text-muted-foreground flex items-center gap-1 mt-0.5">
                      <Timer className="h-3 w-3" /> {AD_DURATION}s video → +1 credit
                    </p>
                  </div>
                  <span className="px-3 py-1 rounded-full bg-accent/20 text-accent text-xs font-bold">FREE</span>
                </button>

                {/* Divider */}
                <div className="flex items-center gap-3">
                  <div className="flex-1 h-px bg-border" />
                  <span className="text-xs text-muted-foreground font-medium">OR</span>
                  <div className="flex-1 h-px bg-border" />
                </div>

                {/* Pro Weekly */}
                <button
                  onClick={() => toast.info("Premium subscription coming soon! Watch ads for now.")}
                  className="w-full flex items-center gap-4 p-4 rounded-xl border-2 border-primary/30 bg-primary/5 hover:border-primary/60 hover:bg-primary/10 transition-all group text-left relative overflow-hidden"
                >
                  <div className="absolute top-0 right-0 px-2 py-0.5 rounded-bl-lg bg-primary text-primary-foreground text-[10px] font-bold">
                    BEST VALUE
                  </div>
                  <div className="flex-shrink-0 h-12 w-12 rounded-xl bg-primary/20 flex items-center justify-center text-primary group-hover:scale-110 transition-transform">
                    <Crown className="h-6 w-6" />
                  </div>
                  <div className="flex-1">
                    <p className="font-semibold text-sm">Pro Weekly — Unlimited</p>
                    <p className="text-xs text-muted-foreground mt-0.5">No watermarks • No ads • Priority</p>
                  </div>
                  <span className="px-3 py-1 rounded-full bg-primary/20 text-primary text-xs font-bold">$9.99/w</span>
                </button>

                {/* 50 Pack */}
                <button
                  onClick={() => toast.info("Credit packs coming soon! Watch ads for now.")}
                  className="w-full flex items-center gap-4 p-4 rounded-xl border border-border bg-muted/30 hover:border-primary/40 hover:bg-muted/60 transition-all group text-left"
                >
                  <div className="flex-shrink-0 h-12 w-12 rounded-xl bg-secondary/40 flex items-center justify-center text-foreground group-hover:scale-110 transition-transform">
                    <Sparkles className="h-6 w-6" />
                  </div>
                  <div className="flex-1">
                    <p className="font-semibold text-sm">50 Credits Pack</p>
                    <p className="text-xs text-muted-foreground mt-0.5">One-time • No expiry</p>
                  </div>
                  <span className="px-3 py-1 rounded-full bg-secondary/40 text-foreground text-xs font-bold">$29.99</span>
                </button>

                {/* Trust badges */}
                <div className="flex items-center justify-center gap-4 pt-3 text-muted-foreground">
                  <div className="flex items-center gap-1 text-[10px]">
                    <ShieldCheck className="h-3 w-3" /> Secure Payment
                  </div>
                  <div className="flex items-center gap-1 text-[10px]">
                    <Zap className="h-3 w-3" /> Instant Access
                  </div>
                </div>
              </div>
            </>
          )}
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
};

export default CreditGateModal;
