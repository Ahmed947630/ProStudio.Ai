import { useState } from "react";
import { motion } from "framer-motion";
import { Download, RefreshCw, Share2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import AdGateModal from "@/components/AdGateModal";

interface ResultGalleryProps {
  images: string[];
  onRegenerate: () => void;
  originalImage?: string;
}

const ResultGallery = ({ images, onRegenerate, originalImage }: ResultGalleryProps) => {
  const [showDownloadAds, setShowDownloadAds] = useState(false);
  const [pendingDownload, setPendingDownload] = useState<{ src: string; index: number } | null>(null);
  const [downloadAll, setDownloadAll] = useState(false);

  const doDownload = (src: string, index: number) => {
    const a = document.createElement("a");
    a.href = src;
    a.download = `prostudio-ai-result-${index + 1}.jpg`;
    a.click();
  };

  const handleDownload = (src: string, index: number) => {
    setPendingDownload({ src, index });
    setDownloadAll(false);
    setShowDownloadAds(true);
  };

  const handleDownloadAll = () => {
    setDownloadAll(true);
    setPendingDownload(null);
    setShowDownloadAds(true);
  };

  const handleAdsComplete = () => {
    setShowDownloadAds(false);
    if (downloadAll) {
      images.forEach((img, i) => {
        setTimeout(() => doDownload(img, i), i * 300);
      });
    } else if (pendingDownload) {
      doDownload(pendingDownload.src, pendingDownload.index);
    }
    setPendingDownload(null);
    setDownloadAll(false);
  };

  return (
    <>
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-8">
        <div className="text-center">
          <h3 className="font-display text-2xl font-bold mb-2">Your Results Are Ready! 🎉</h3>
          <p className="text-muted-foreground text-sm">Choose your favorite or regenerate for new variations</p>
        </div>

        {originalImage && (
          <div className="flex justify-center">
            <div className="rounded-xl border border-border overflow-hidden w-32 h-32">
              <img src={originalImage} alt="Original" className="w-full h-full object-cover" />
              <p className="text-xs text-muted-foreground text-center mt-1">Original</p>
            </div>
          </div>
        )}

        <div className="grid grid-cols-2 gap-4">
          {images.map((img, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: i * 0.15 }}
              className="group relative rounded-2xl border border-border overflow-hidden bg-card"
            >
              <img src={img} alt={`Result ${i + 1}`} className="w-full aspect-[3/4] object-cover" />
              <div className="absolute inset-0 bg-background/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-3">
                <Button size="icon" variant="hero" onClick={() => handleDownload(img, i)}>
                  <Download className="h-4 w-4" />
                </Button>
                <Button size="icon" variant="hero-outline">
                  <Share2 className="h-4 w-4" />
                </Button>
              </div>
              <div className="absolute top-2 right-2 px-2 py-0.5 rounded-full bg-background/80 text-xs font-medium text-primary">
                #{i + 1}
              </div>
            </motion.div>
          ))}
        </div>

        <div className="flex justify-center gap-4">
          <Button variant="hero-outline" onClick={onRegenerate} className="gap-2">
            <RefreshCw className="h-4 w-4" /> Regenerate
          </Button>
          <Button variant="hero" className="gap-2" onClick={handleDownloadAll}>
            <Download className="h-4 w-4" /> Download All
          </Button>
        </div>
      </motion.div>

      <AdGateModal
        open={showDownloadAds}
        onClose={() => { setShowDownloadAds(false); setPendingDownload(null); setDownloadAll(false); }}
        onComplete={handleAdsComplete}
        adCount={3}
        title="Watch 3 Ads to Download"
        subtitle="Watch 3 short ads (15s each) to unlock your image download"
      />
    </>
  );
};

export default ResultGallery;
