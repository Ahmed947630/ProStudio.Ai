import { useState, useEffect, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";

export function useCreditGate() {
  const { user } = useAuth();
  const [credits, setCredits] = useState<number | null>(null);
  const [showGate, setShowGate] = useState(false);
  const [loading, setLoading] = useState(true);

  const fetchCredits = useCallback(async () => {
    if (!user) { setCredits(null); setLoading(false); return; }
    const { data } = await supabase
      .from("profiles")
      .select("credits")
      .eq("user_id", user.id)
      .single();
    setCredits(data?.credits ?? 0);
    setLoading(false);
  }, [user]);

  useEffect(() => { fetchCredits(); }, [fetchCredits]);

  // Returns true if user can proceed, false if gate should show
  const checkCredits = useCallback((): boolean => {
    if (credits === null || credits <= 0) {
      setShowGate(true);
      return false;
    }
    return true;
  }, [credits]);

  // Deduct 1 credit after successful generation
  const deductCredit = useCallback(async () => {
    if (!user) return;
    const newCredits = Math.max((credits ?? 0) - 1, 0);
    await supabase
      .from("profiles")
      .update({ credits: newCredits })
      .eq("user_id", user.id);
    setCredits(newCredits);
  }, [user, credits]);

  const closeGate = useCallback(() => setShowGate(false), []);

  return {
    credits,
    showGate,
    loading,
    checkCredits,
    deductCredit,
    closeGate,
    refreshCredits: fetchCredits,
  };
}
