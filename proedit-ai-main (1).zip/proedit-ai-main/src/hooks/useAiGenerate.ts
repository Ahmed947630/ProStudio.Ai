import { useState, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

interface GenerateOptions {
  feature: string;
  options?: Record<string, string>;
  imageBase64?: string;
}

export function useAiGenerate() {
  const [isGenerating, setIsGenerating] = useState(false);
  const [results, setResults] = useState<string[]>([]);

  const saveGeneration = useCallback(async (feature: string, imageUrl: string, prompt?: string) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      await supabase.from("generations").insert({
        user_id: user.id,
        feature,
        result_url: imageUrl,
        input_prompt: prompt || null,
        status: "completed",
      });
    } catch (err) {
      console.error("Failed to save generation:", err);
    }
  }, []);

  const generate = useCallback(async ({ feature, options, imageBase64 }: GenerateOptions) => {
    setIsGenerating(true);
    setResults([]);

    try {
      const { data, error } = await supabase.functions.invoke("ai-generate", {
        body: { feature, options, imageBase64 },
      });

      if (error) {
        console.error("Generation error:", error);
        toast.error("AI generation failed. Please try again.");
        return [];
      }

      if (data?.error) {
        toast.error(data.error);
        return [];
      }

      const images = data?.images || [];
      setResults(images);
      
      if (images.length === 0) {
        toast.error("No images generated. Please try again.");
      } else {
        // Save each generated image to the generations table
        const prompt = options ? Object.values(options).filter(Boolean).join(", ") : undefined;
        await Promise.all(images.map((img: string) => saveGeneration(feature, img, prompt)));
      }

      return images;
    } catch (err) {
      console.error("Generation error:", err);
      toast.error("Something went wrong. Please try again.");
      return [];
    } finally {
      setIsGenerating(false);
    }
  }, [saveGeneration]);

  const reset = useCallback(() => {
    setResults([]);
    setIsGenerating(false);
  }, []);

  return { generate, isGenerating, results, reset };
}
