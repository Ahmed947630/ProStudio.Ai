import { ArrowLeft } from "lucide-react";
import { Link } from "react-router-dom";

const PrivacyPolicy = () => {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <div className="max-w-3xl mx-auto px-4 py-8 safe-top safe-bottom">
        <Link to="/" className="inline-flex items-center gap-2 text-muted-foreground hover:text-primary mb-8 transition-colors">
          <ArrowLeft className="h-4 w-4" />
          Back to Home
        </Link>

        <h1 className="font-display text-3xl font-bold mb-2">Privacy Policy</h1>
        <p className="text-muted-foreground mb-8">Last updated: March 8, 2026</p>

        <div className="prose prose-invert max-w-none space-y-6 text-muted-foreground">
          <section>
            <h2 className="text-xl font-semibold text-foreground">1. Introduction</h2>
            <p>Welcome to Pro Studio AI ("we," "our," or "us"). We are committed to protecting your personal information and your right to privacy. This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you use our mobile application.</p>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-foreground">2. Information We Collect</h2>
            <p>We may collect the following types of information:</p>
            <ul className="list-disc pl-6 space-y-2">
              <li><strong className="text-foreground">Account Information:</strong> Email address and display name when you create an account.</li>
              <li><strong className="text-foreground">Uploaded Images:</strong> Photos you upload for AI processing. These are processed temporarily and not stored permanently on our servers.</li>
              <li><strong className="text-foreground">Usage Data:</strong> Information about how you use the app, including features accessed and generation history.</li>
              <li><strong className="text-foreground">Device Information:</strong> Device type, operating system, and unique device identifiers.</li>
              <li><strong className="text-foreground">Advertising Data:</strong> We use Google AdMob which may collect advertising identifiers for personalized ads.</li>
            </ul>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-foreground">3. How We Use Your Information</h2>
            <ul className="list-disc pl-6 space-y-2">
              <li>To provide and maintain our AI image processing services</li>
              <li>To manage your account and track usage credits</li>
              <li>To improve and optimize our application</li>
              <li>To display relevant advertisements</li>
              <li>To communicate with you about updates and features</li>
            </ul>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-foreground">4. Image Processing & Storage</h2>
            <p>Images you upload are processed using AI models to generate results. Uploaded images are temporarily stored during processing and are automatically deleted after generation is complete. We do not use your images to train AI models.</p>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-foreground">5. Third-Party Services</h2>
            <p>Our app integrates with the following third-party services:</p>
            <ul className="list-disc pl-6 space-y-2">
              <li><strong className="text-foreground">Google AdMob:</strong> For displaying advertisements. See Google's Privacy Policy for more details.</li>
              <li><strong className="text-foreground">Cloud Backend:</strong> For authentication and data storage.</li>
              <li><strong className="text-foreground">AI Processing Services:</strong> For image generation and editing.</li>
            </ul>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-foreground">6. Data Security</h2>
            <p>We implement appropriate technical and organizational security measures to protect your personal information. However, no electronic transmission over the Internet or information storage technology can be guaranteed to be 100% secure.</p>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-foreground">7. Children's Privacy</h2>
            <p>Our app is not intended for children under 13 years of age. We do not knowingly collect personal information from children under 13.</p>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-foreground">8. Your Rights</h2>
            <p>You have the right to access, correct, or delete your personal information. You can delete your account at any time from the Profile page, which will remove all associated data.</p>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-foreground">9. Contact Us</h2>
            <p>If you have questions about this Privacy Policy, please contact us at: <a href="mailto:support@prostudioai.com" className="text-primary hover:underline">support@prostudioai.com</a></p>
          </section>
        </div>
      </div>
    </div>
  );
};

export default PrivacyPolicy;
