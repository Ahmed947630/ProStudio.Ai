import { useState, useCallback, useEffect } from "react";
import { motion } from "framer-motion";
import { X, ZoomIn, ZoomOut, Check, Sparkles, Minus, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import FeatureLayout from "@/components/FeatureLayout";
import UploadZone from "@/components/UploadZone";
import ResultGallery from "@/components/ResultGallery";
import { useAiGenerate } from "@/hooks/useAiGenerate";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";

type Step = "upload" | "editor" | "processing" | "result";

const RESOLUTION_MARKS = [
  { value: 0, label: "2K", resolution: "2K" },
  { value: 20, label: "4K", resolution: "4K" },
  { value: 40, label: "8K", resolution: "8K" },
  { value: 60, label: "12K", resolution: "12K" },
  { value: 80, label: "16K", resolution: "16K" },
  { value: 100, label: "18K", resolution: "18K" },
];

const ENHANCE_OPTIONS = [
  { label: "Auto Color", value: "auto-color", desc: "Fix color balance & vibrancy" },
  { label: "Face Restore", value: "face-restore", desc: "Enhance facial details" },
  { label: "Denoise", value: "denoise", desc: "Remove grain & noise" },
  { label: "Sharpen", value: "sharpen", desc: "Crisp edge details" },
];

const WATERMARK_TEXT = "Rajput editor/ pro studio.Ai";

const Upscaler = () => {
  const [step, setStep] = useState<Step>("upload");
  const [uploadedImage, setUploadedImage] = useState<string | null>(null);
  const [resValue, setResValue] = useState([100]);
  const [selectedEnhancements, setSelectedEnhancements] = useState<string[]>(["auto-color", "face-restore"]);
  const [progress, setProgress] = useState(0);
  const [zoom, setZoom] = useState(1);
  const [isPremium, setIsPremium] = useState(false);
  const { generate, results, reset: resetAi } = useAiGenerate();
  const { user } = useAuth();

  // Check if user is premium (credits > 0 means paid user)
  useEffect(() => {
    const checkPremium = async () => {
      if (!user) { setIsPremium(false); return; }
      const { data } = await supabase
        .from("profiles")
        .select("credits")
        .eq("user_id", user.id)
        .single();
      setIsPremium((data?.credits ?? 0) > 3);
    };
    checkPremium();
  }, [user]);

  const handleUpload = useCallback((files: File[]) => {
    setUploadedImage(URL.createObjectURL(files[0]));
    setStep("editor");
    setZoom(1);
  }, []);

  const getResLabel = () => {
    const mark = RESOLUTION_MARKS.reduce((prev, curr) =>
      Math.abs(curr.value - resValue[0]) < Math.abs(prev.value - resValue[0]) ? curr : prev
    );
    return mark.label;
  };

  const getResolution = () => {
    const mark = RESOLUTION_MARKS.reduce((prev, curr) =>
      Math.abs(curr.value - resValue[0]) < Math.abs(prev.value - resValue[0]) ? curr : prev
    );
    return mark.resolution;
  };

  const toggleEnhancement = (value: string) => {
    setSelectedEnhancements((prev) =>
      prev.includes(value) ? prev.filter((v) => v !== value) : [...prev, value]
    );
  };

  const handleZoomIn = () => setZoom((z) => Math.min(z + 0.25, 3));
  const handleZoomOut = () => setZoom((z) => Math.max(z - 0.25, 0.5));

  const toBase64 = (url: string): Promise<string> =>
    fetch(url).then((r) => r.blob()).then(
      (blob) => new Promise((resolve) => {
        const reader = new FileReader();
        reader.onloadend = () => resolve(reader.result as string);
        reader.readAsDataURL(blob);
      })
    );

  // Professional side watermark for free users only
  const addWatermark = (imageSrc: string): Promise<string> =>
    new Promise((resolve) => {
      const img = new Image();
      img.crossOrigin = "anonymous";
      img.onload = () => {
        const canvas = document.createElement("canvas");
        canvas.width = img.width;
        canvas.height = img.height;
        const ctx = canvas.getContext("2d")!;
        ctx.drawImage(img, 0, 0);

        const fontSize = Math.max(img.width * 0.028, 14);

        // Right-side vertical watermark strip
        const stripW = fontSize * 8;
        const gradient = ctx.createLinearGradient(img.width - stripW, 0, img.width, 0);
        gradient.addColorStop(0, "rgba(0, 0, 0, 0)");
        gradient.addColorStop(0.3, "rgba(0, 0, 0, 0.45)");
        gradient.addColorStop(1, "rgba(0, 0, 0, 0.65)");
        ctx.fillStyle = gradient;
        ctx.fillRect(img.width - stripW, 0, stripW, img.height);

        // Vertical text on right side
        ctx.save();
        ctx.translate(img.width - fontSize * 1.2, img.height / 2);
        ctx.rotate(-Math.PI / 2);
        ctx.font = `600 ${fontSize}px 'Segoe UI', sans-serif`;
        ctx.fillStyle = "rgba(255, 255, 255, 0.85)";
        ctx.textAlign = "center";
        ctx.letterSpacing = "2px";
        ctx.fillText(WATERMARK_TEXT, 0, 0);
        ctx.restore();

        // Small bottom-right badge
        const badgeH = fontSize * 1.8;
        const badgeW = fontSize * 9;
        const badgeX = img.width - badgeW - fontSize * 0.5;
        const badgeY = img.height - badgeH - fontSize * 0.5;
        ctx.fillStyle = "rgba(0, 0, 0, 0.55)";
        ctx.beginPath();
        ctx.roundRect(badgeX, badgeY, badgeW, badgeH, fontSize * 0.4);
        ctx.fill();
        ctx.font = `600 ${fontSize * 0.75}px 'Segoe UI', sans-serif`;
        ctx.fillStyle = "rgba(255, 255, 255, 0.9)";
        ctx.textAlign = "center";
        ctx.fillText(WATERMARK_TEXT, badgeX + badgeW / 2, badgeY + badgeH / 2 + fontSize * 0.25);

        resolve(canvas.toDataURL("image/jpeg", 0.92));
      };
      img.src = imageSrc;
    });

  const handleGenerate = async () => {
    setStep("processing");
    setProgress(0);

    const interval = setInterval(() => {
      setProgress((p) => {
        if (p >= 95) { clearInterval(interval); return 95; }
        return p + Math.random() * 6;
      });
    }, 600);

    let imageBase64: string | undefined;
    if (uploadedImage) imageBase64 = await toBase64(uploadedImage);

    const imgs = await generate({
      feature: "upscale",
      options: {
        mode: "upscale",
        resolution: getResolution(),
        enhancements: selectedEnhancements.join(","),
      },
      imageBase64,
    });

    clearInterval(interval);
    setProgress(100);

    setTimeout(() => {
      if (imgs.length > 0) {
        setStep("result");
      } else setStep("editor");
    }, 300);
  };

  const handleReset = () => {
    setStep("upload");
    setUploadedImage(null);
    setResValue([100]);
    setSelectedEnhancements(["auto-color", "face-restore"]);
    setZoom(1);
    resetAi();
  };

  // Apply watermark only for free users
  const [watermarkedResults, setWatermarkedResults] = useState<string[]>([]);
  const applyWatermarks = useCallback(async (images: string[]) => {
    if (isPremium) {
      setWatermarkedResults(images);
      return;
    }
    const marked = await Promise.all(images.map((img) => addWatermark(img)));
    setWatermarkedResults(marked);
  }, [isPremium]);

  // When results change, apply watermarks
  if (results.length > 0 && watermarkedResults.length === 0 && step === "result") {
    applyWatermarks(results);
  }

  const displayResults = watermarkedResults.length > 0 ? watermarkedResults : results;

  return (
    <FeatureLayout
      title="18K AI Enhance"
      subtitle="Upscale any image to ultra HD with auto color correction, face restoration & denoising"
    >
      {step === "upload" && (
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
          <UploadZone
            onFileSelect={handleUpload}
            label="Upload a photo to enhance"
            sublabel="Old, blurry, or low-resolution — AI will make it crystal clear"
          />
        </motion.div>
      )}

      {step === "editor" && uploadedImage && (
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="flex flex-col gap-0 max-w-lg mx-auto">
          {/* Image Preview */}
          <div className="relative bg-[repeating-conic-gradient(hsl(var(--muted))_0%_25%,hsl(var(--background))_0%_50%)] bg-[length:20px_20px] rounded-t-2xl overflow-hidden flex items-center justify-center min-h-[350px] md:min-h-[420px]">
            <div
              className="relative transition-transform duration-200 ease-out"
              style={{ transform: `scale(${zoom})`, maxWidth: "65%" }}
            >
              <img src={uploadedImage} alt="Preview" className="w-full h-auto object-contain rounded-lg shadow-xl" />
              <div className="absolute inset-0 rounded-lg border-2 border-primary/20" />
              <div className="absolute -top-2 -right-2 flex h-8 w-8 items-center justify-center rounded-full bg-primary text-primary-foreground shadow-lg">
                <Sparkles className="h-4 w-4" />
              </div>
            </div>

            {/* Resolution badge */}
            <div className="absolute bottom-3 left-3 flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-primary/90 text-primary-foreground text-xs font-bold">
              <ZoomIn className="h-3 w-3" />
              {getResLabel()} Ultra HD
            </div>

            {/* Zoom Controls */}
            <div className="absolute bottom-3 right-3 flex items-center gap-1">
              <button
                onClick={handleZoomOut}
                disabled={zoom <= 0.5}
                className="flex h-8 w-8 items-center justify-center rounded-full bg-background/80 backdrop-blur-sm border border-border/50 text-foreground hover:bg-background transition-colors disabled:opacity-30"
              >
                <Minus className="h-3.5 w-3.5" />
              </button>
              <span className="px-2 py-1 rounded-full bg-background/80 backdrop-blur-sm text-[11px] font-bold text-foreground border border-border/50 min-w-[3rem] text-center">
                {Math.round(zoom * 100)}%
              </span>
              <button
                onClick={handleZoomIn}
                disabled={zoom >= 3}
                className="flex h-8 w-8 items-center justify-center rounded-full bg-background/80 backdrop-blur-sm border border-border/50 text-foreground hover:bg-background transition-colors disabled:opacity-30"
              >
                <Plus className="h-3.5 w-3.5" />
              </button>
            </div>

            {/* Enhancement badges */}
            <div className="absolute top-3 right-3 flex flex-col gap-1">
              {selectedEnhancements.map((e) => {
                const opt = ENHANCE_OPTIONS.find((o) => o.value === e);
                return opt ? (
                  <span key={e} className="px-2 py-0.5 rounded-full bg-background/80 backdrop-blur-sm text-[10px] font-semibold text-foreground border border-border/50">
                    ✓ {opt.label}
                  </span>
                ) : null;
              })}
            </div>
          </div>

          {/* Bottom Panel */}
          <div className="bg-card rounded-b-2xl border border-border border-t-0">
            <div className="p-5 space-y-5">
              {/* Header */}
              <div className="flex items-center justify-between">
                <button onClick={handleReset} className="text-foreground hover:text-primary transition-colors">
                  <X className="h-5 w-5" />
                </button>
                <h3 className="font-display text-base font-semibold flex items-center gap-2">
                  <ZoomIn className="h-4 w-4 text-primary" />
                  18K Enhance
                </h3>
                <button onClick={handleGenerate} className="text-foreground hover:text-primary transition-colors">
                  <Check className="h-5 w-5" />
                </button>
              </div>

              {/* Resolution Slider */}
              <div className="space-y-3">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Target Resolution</span>
                  <span className="font-bold text-primary text-lg">{getResLabel()}</span>
                </div>
                <Slider value={resValue} onValueChange={setResValue} max={100} step={1} className="w-full" />
                <div className="flex justify-between text-xs text-muted-foreground">
                  {RESOLUTION_MARKS.map((m) => (
                    <span key={m.value} className={resValue[0] >= m.value - 5 && resValue[0] <= m.value + 5 ? "text-primary font-bold" : ""}>
                      {m.label}
                    </span>
                  ))}
                </div>
              </div>

              {/* Enhancement Options */}
              <div className="space-y-2">
                <span className="text-sm font-medium text-muted-foreground">Auto Enhancements</span>
                <div className="grid grid-cols-2 gap-2">
                  {ENHANCE_OPTIONS.map((opt) => (
                    <button
                      key={opt.value}
                      onClick={() => toggleEnhancement(opt.value)}
                      className={`flex flex-col items-start p-3 rounded-xl border text-left transition-all ${
                        selectedEnhancements.includes(opt.value)
                          ? "border-primary bg-primary/10 shadow-sm"
                          : "border-border hover:border-foreground/20"
                      }`}
                    >
                      <span className={`text-sm font-semibold ${selectedEnhancements.includes(opt.value) ? "text-primary" : "text-foreground"}`}>
                        {opt.label}
                      </span>
                      <span className="text-[11px] text-muted-foreground leading-tight">{opt.desc}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Generate */}
              <Button
                onClick={handleGenerate}
                className="w-full h-12 text-base font-bold rounded-xl bg-[hsl(75_70%_50%)] hover:bg-[hsl(75_70%_45%)] text-[hsl(220_20%_7%)]"
              >
                <Sparkles className="h-4 w-4 mr-2" />
                Enhance to {getResLabel()}
              </Button>
            </div>
          </div>
        </motion.div>
      )}

      {step === "processing" && uploadedImage && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex flex-col gap-0 max-w-lg mx-auto">
          <div className="relative bg-[repeating-conic-gradient(hsl(var(--muted))_0%_25%,hsl(var(--background))_0%_50%)] bg-[length:20px_20px] rounded-t-2xl overflow-hidden flex items-center justify-center min-h-[350px] md:min-h-[420px]">
            <div className="relative max-w-[65%]">
              <img src={uploadedImage} alt="Preview" className="w-full h-auto object-contain rounded-lg opacity-80" />
            </div>
            <div className="absolute inset-0 flex flex-col items-center justify-end pb-16 bg-background/30">
              <div className="relative w-16 h-16 mb-3">
                <div className="absolute inset-0 rounded-full border-2 border-[hsl(75_70%_50%)/0.3] animate-spin" style={{ borderTopColor: "hsl(75 70% 50%)" }} />
                <div className="absolute inset-1 rounded-full border-2 border-[hsl(75_70%_50%)/0.15] animate-spin" style={{ animationDirection: "reverse", animationDuration: "1.5s", borderBottomColor: "hsl(75 70% 50% / 0.5)" }} />
              </div>
              <p className="text-foreground font-display font-semibold text-base">
                Enhancing to {getResLabel()}... {Math.round(progress)}%
              </p>
            </div>
          </div>
          <div className="bg-card rounded-b-2xl border border-border border-t-0 p-5 opacity-50 pointer-events-none">
            <Button disabled className="w-full h-12 text-base font-bold rounded-xl bg-[hsl(75_70%_40%)] text-[hsl(220_20%_7%)]">
              Enhancing...
            </Button>
          </div>
        </motion.div>
      )}

      {step === "result" && (
        <ResultGallery images={displayResults} originalImage={uploadedImage || undefined} onRegenerate={() => { setWatermarkedResults([]); handleReset(); }} />
      )}

    </FeatureLayout>
  );
};

export default Upscaler;
