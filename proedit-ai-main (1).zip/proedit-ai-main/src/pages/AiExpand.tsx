import { useState, useCallback } from "react";
import { motion } from "framer-motion";
import { X, Check, Expand } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Textarea } from "@/components/ui/textarea";
import FeatureLayout from "@/components/FeatureLayout";
import UploadZone from "@/components/UploadZone";
import ResultGallery from "@/components/ResultGallery";
import { useAiGenerate } from "@/hooks/useAiGenerate";

type Step = "upload" | "editor" | "processing" | "result";
type ExpandTab = "keep" | "change";

const SCALE_MARKS = [
  { value: 0, label: "1.2x" },
  { value: 25, label: "1.5x" },
  { value: 50, label: "2x" },
  { value: 75, label: "2.5x" },
  { value: 100, label: "3x" },
];

const ASPECT_RATIOS = [
  { label: "1:1", value: "1:1" },
  { label: "3:4", value: "3:4" },
  { label: "9:16", value: "9:16" },
  { label: "16:9", value: "16:9" },
  { label: "4:3", value: "4:3" },
];

const AiExpand = () => {
  const [step, setStep] = useState<Step>("upload");
  const [uploadedImage, setUploadedImage] = useState<string | null>(null);
  const [expandTab, setExpandTab] = useState<ExpandTab>("keep");
  const [scaleValue, setScaleValue] = useState([50]);
  const [selectedRatio, setSelectedRatio] = useState("1:1");
  const [prompt, setPrompt] = useState("");
  const [progress, setProgress] = useState(0);
  const { generate, results, reset: resetAi } = useAiGenerate();

  const handleUpload = useCallback((files: File[]) => {
    setUploadedImage(URL.createObjectURL(files[0]));
    setStep("editor");
  }, []);

  const getScaleLabel = () => {
    const mark = SCALE_MARKS.reduce((prev, curr) =>
      Math.abs(curr.value - scaleValue[0]) < Math.abs(prev.value - scaleValue[0]) ? curr : prev
    );
    return mark.label;
  };

  const getScaleMultiplier = () => {
    const v = scaleValue[0];
    return 1 + (v / 100) * 2;
  };

  const toBase64 = (url: string): Promise<string> =>
    fetch(url).then((r) => r.blob()).then(
      (blob) => new Promise((resolve) => {
        const reader = new FileReader();
        reader.onloadend = () => resolve(reader.result as string);
        reader.readAsDataURL(blob);
      })
    );

  const handleGenerate = async () => {
    setStep("processing");
    setProgress(0);

    const interval = setInterval(() => {
      setProgress((p) => {
        if (p >= 95) { clearInterval(interval); return 95; }
        return p + Math.random() * 8;
      });
    }, 500);

    let imageBase64: string | undefined;
    if (uploadedImage) imageBase64 = await toBase64(uploadedImage);

    const ratio = expandTab === "change" ? selectedRatio : undefined;

    const imgs = await generate({
      feature: "ai-expand",
      options: {
        mode: "uncrop",
        scale: getScaleLabel(),
        ratio: ratio || "",
        prompt: prompt || "",
      },
      imageBase64,
    });

    clearInterval(interval);
    setProgress(100);

    setTimeout(() => {
      if (imgs.length > 0) {
        setStep("result");
      } else setStep("editor");
    }, 300);
  };

  const handleReset = () => {
    setStep("upload");
    setUploadedImage(null);
    setPrompt("");
    setScaleValue([50]);
    resetAi();
  };

  const getExpandPreviewStyle = () => {
    const scale = getScaleMultiplier();
    const imgSize = 100 / scale;
    return { width: `${imgSize}%`, height: `${imgSize}%` };
  };

  return (
    <FeatureLayout
      title="AI Expand & Uncrop"
      subtitle="Extend your image canvas with AI-generated content — add scenery, backgrounds, or expand any direction"
    >
      {step === "upload" && (
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
          <UploadZone
            onFileSelect={handleUpload}
            label="Upload a photo to expand"
            sublabel="AI will generate content beyond your image boundaries"
          />
        </motion.div>
      )}

      {step === "editor" && uploadedImage && (
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="flex flex-col gap-0 max-w-lg mx-auto">
          {/* Image Preview */}
          <div className="relative bg-[repeating-conic-gradient(hsl(var(--muted))_0%_25%,hsl(var(--background))_0%_50%)] bg-[length:20px_20px] rounded-t-2xl overflow-hidden flex items-center justify-center min-h-[350px] md:min-h-[420px]">
            {expandTab === "keep" ? (
              <div className="relative w-full h-full flex items-center justify-center p-6" style={{ minHeight: 350 }}>
                {/* Outer expand boundary */}
                <div className="absolute inset-6 border-2 border-dashed border-primary/30 rounded-xl" />
                <div className="relative z-10 transition-all duration-500 ease-out" style={getExpandPreviewStyle()}>
                  <img src={uploadedImage} alt="Preview" className="w-full h-full object-cover rounded-lg shadow-lg" />
                </div>
              </div>
            ) : (
              <div className="relative w-full h-full flex items-center justify-center p-6" style={{ minHeight: 350 }}>
                <div className="absolute inset-6 border-2 border-dashed border-primary/30 rounded-xl" />
                <div className="relative max-w-[55%] z-10">
                  <img src={uploadedImage} alt="Preview" className="w-full h-auto object-cover rounded-lg shadow-lg" />
                </div>
              </div>
            )}

            {/* Expand indicator */}
            <div className="absolute bottom-3 right-3 flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-primary/90 text-primary-foreground text-xs font-semibold">
              <Expand className="h-3 w-3" />
              AI Fill
            </div>
          </div>

          {/* Bottom Panel */}
          <div className="bg-card rounded-b-2xl border border-border border-t-0">
            <div className="p-5 space-y-5">
              {/* Panel Header */}
              <div className="flex items-center justify-between">
                <button onClick={handleReset} className="text-foreground hover:text-primary transition-colors">
                  <X className="h-5 w-5" />
                </button>
                <h3 className="font-display text-base font-semibold flex items-center gap-2">
                  <Expand className="h-4 w-4 text-primary" />
                  AI Expand
                </h3>
                <button onClick={handleGenerate} className="text-foreground hover:text-primary transition-colors">
                  <Check className="h-5 w-5" />
                </button>
              </div>

              {/* Keep / Change Tabs */}
              <div className="flex gap-1 p-1 rounded-xl bg-muted/50">
                <button
                  onClick={() => setExpandTab("keep")}
                  className={`flex-1 text-sm font-semibold py-2 rounded-lg transition-all ${expandTab === "keep" ? "bg-background text-foreground shadow-sm" : "text-muted-foreground hover:text-foreground"}`}
                >
                  Keep Aspect Ratio
                </button>
                <button
                  onClick={() => setExpandTab("change")}
                  className={`flex-1 text-sm font-semibold py-2 rounded-lg transition-all ${expandTab === "change" ? "bg-background text-foreground shadow-sm" : "text-muted-foreground hover:text-foreground"}`}
                >
                  Change Aspect Ratio
                </button>
              </div>

              {/* Scale or Ratio */}
              {expandTab === "keep" ? (
                <div className="space-y-3">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">Expand Scale</span>
                    <span className="font-semibold text-primary">{getScaleLabel()}</span>
                  </div>
                  <Slider value={scaleValue} onValueChange={setScaleValue} max={100} step={1} className="w-full" />
                  <div className="flex justify-between text-xs text-muted-foreground">
                    {SCALE_MARKS.map((m) => (
                      <span key={m.value} className={scaleValue[0] >= m.value - 5 && scaleValue[0] <= m.value + 5 ? "text-foreground font-medium" : ""}>
                        {m.label}
                      </span>
                    ))}
                  </div>
                </div>
              ) : (
                <div className="flex gap-2 overflow-x-auto pb-1">
                  {ASPECT_RATIOS.map((r) => (
                    <button
                      key={r.value}
                      onClick={() => setSelectedRatio(r.value)}
                      className={`flex items-center justify-center px-4 py-2.5 rounded-xl border text-sm font-medium transition-all min-w-[56px] ${
                        selectedRatio === r.value
                          ? "border-primary bg-primary/10 text-primary shadow-sm"
                          : "border-border text-muted-foreground hover:border-foreground/30"
                      }`}
                    >
                      <div className={`border-2 rounded-sm mr-2 ${
                        selectedRatio === r.value ? "border-primary" : "border-muted-foreground/50"
                      }`} style={{
                        width: r.value === "16:9" || r.value === "4:3" ? 18 : r.value === "1:1" ? 14 : 10,
                        height: r.value === "9:16" || r.value === "3:4" ? 18 : r.value === "1:1" ? 14 : 10,
                      }} />
                      {r.label}
                    </button>
                  ))}
                </div>
              )}

              {/* Prompt Input */}
              <div className="space-y-2">
                <label className="text-sm font-medium text-muted-foreground">Describe what to fill (optional)</label>
                <Textarea
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                  placeholder="e.g. Continue the beach scenery with palm trees and sunset sky..."
                  className="min-h-[72px] resize-none rounded-xl bg-muted/30 border-border/50 focus:border-primary/50 text-sm"
                  rows={2}
                />
              </div>

              {/* Generate */}
              <Button
                onClick={handleGenerate}
                className="w-full h-12 text-base font-bold rounded-xl bg-[hsl(75_70%_50%)] hover:bg-[hsl(75_70%_45%)] text-[hsl(220_20%_7%)]"
              >
                <Expand className="h-4 w-4 mr-2" />
                Expand Image
              </Button>
            </div>
          </div>
        </motion.div>
      )}

      {step === "processing" && uploadedImage && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex flex-col gap-0 max-w-lg mx-auto">
          <div className="relative bg-[repeating-conic-gradient(hsl(var(--muted))_0%_25%,hsl(var(--background))_0%_50%)] bg-[length:20px_20px] rounded-t-2xl overflow-hidden flex items-center justify-center min-h-[350px] md:min-h-[420px]">
            <div className="relative max-w-[55%]">
              <img src={uploadedImage} alt="Preview" className="w-full h-auto object-cover rounded-lg opacity-80" />
            </div>
            <div className="absolute inset-0 flex flex-col items-center justify-end pb-16 bg-background/30">
              <div className="relative w-16 h-16 mb-3">
                <div className="absolute inset-0 rounded-full border-2 border-[hsl(75_70%_50%)/0.3] animate-spin" style={{ borderTopColor: "hsl(75 70% 50%)" }} />
                <div className="absolute inset-1 rounded-full border-2 border-[hsl(75_70%_50%)/0.15] animate-spin" style={{ animationDirection: "reverse", animationDuration: "1.5s", borderBottomColor: "hsl(75 70% 50% / 0.5)" }} />
              </div>
              <p className="text-foreground font-display font-semibold text-base">
                Expanding... {Math.round(progress)}%
              </p>
            </div>
          </div>
          <div className="bg-card rounded-b-2xl border border-border border-t-0 p-5 opacity-50 pointer-events-none">
            <Button disabled className="w-full h-12 text-base font-bold rounded-xl bg-[hsl(75_70%_40%)] text-[hsl(220_20%_7%)]">
              Expanding...
            </Button>
          </div>
        </motion.div>
      )}

      {step === "result" && (
        <ResultGallery images={results} originalImage={uploadedImage || undefined} onRegenerate={handleReset} />
      )}
    </FeatureLayout>
  );
};

export default AiExpand;
