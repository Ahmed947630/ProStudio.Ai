import { useState, useCallback } from "react";
import { motion } from "framer-motion";
import { Camera, Briefcase, GraduationCap, Building2 } from "lucide-react";
import FeatureLayout from "@/components/FeatureLayout";
import UploadZone from "@/components/UploadZone";
import ProcessingScreen from "@/components/ProcessingScreen";
import ResultGallery from "@/components/ResultGallery";
import AdGateModal from "@/components/AdGateModal";
import { useAiGenerate } from "@/hooks/useAiGenerate";

type Step = "upload" | "style" | "processing" | "result";

const styles = [
  { id: "corporate", label: "Corporate Suit", icon: Briefcase, desc: "Classic business suit with studio lighting" },
  { id: "casual", label: "Smart Casual", icon: Camera, desc: "Blazer with modern office backdrop" },
  { id: "academic", label: "Academic", icon: GraduationCap, desc: "Professional academic portrait" },
  { id: "executive", label: "Executive", icon: Building2, desc: "C-suite level premium headshot" },
];

const HeadshotGenerator = () => {
  const [step, setStep] = useState<Step>("upload");
  const [selectedStyle, setSelectedStyle] = useState<string | null>(null);
  const [uploadedImage, setUploadedImage] = useState<string | null>(null);
  const [showAdGate, setShowAdGate] = useState(false);
  const [pendingStyleId, setPendingStyleId] = useState<string | null>(null);
  const { generate, results, reset: resetAi } = useAiGenerate();

  const handleUpload = useCallback((files: File[]) => {
    setUploadedImage(URL.createObjectURL(files[0]));
    setStep("style");
  }, []);

  const toBase64 = (url: string): Promise<string> =>
    fetch(url).then((r) => r.blob()).then(
      (blob) => new Promise((resolve) => {
        const reader = new FileReader();
        reader.onloadend = () => resolve(reader.result as string);
        reader.readAsDataURL(blob);
      })
    );

  const handleStyleSelect = (id: string) => {
    setPendingStyleId(id);
    setShowAdGate(true);
  };

  const handleAdComplete = async () => {
    setShowAdGate(false);
    if (!pendingStyleId) return;
    setSelectedStyle(pendingStyleId);
    setStep("processing");

    let imageBase64: string | undefined;
    if (uploadedImage) imageBase64 = await toBase64(uploadedImage);

    const imgs = await generate({
      feature: "headshot",
      options: { style: pendingStyleId },
      imageBase64,
    });

    if (imgs.length > 0) {
      setStep("result");
    } else {
      setStep("style");
    }
  };

  const handleReset = () => {
    setStep("upload");
    setSelectedStyle(null);
    setUploadedImage(null);
    resetAi();
  };

  return (
    <FeatureLayout
      title="AI Corporate Headshots"
      subtitle="Upload your selfie → Watch a short ad → Get studio-quality professional headshots"
    >
      {step === "upload" && (
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
          <UploadZone
            onFileSelect={handleUpload}
            multiple
            label="Upload 1-3 selfies"
            sublabel="Clear front-facing photos work best • JPG, PNG"
          />
          <div className="mt-6 grid grid-cols-3 gap-4 text-center">
            {["✅ Good lighting", "✅ Front facing", "✅ Clear face"].map((tip) => (
              <div key={tip} className="rounded-xl border border-border bg-card p-3 text-sm text-muted-foreground">{tip}</div>
            ))}
          </div>
        </motion.div>
      )}

      {step === "style" && (
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
          {uploadedImage && (
            <div className="flex justify-center">
              <div className="w-32 h-32 rounded-2xl overflow-hidden border border-primary/30">
                <img src={uploadedImage} alt="Your selfie" className="w-full h-full object-cover" />
              </div>
            </div>
          )}
          <h3 className="font-display text-xl font-semibold text-center">Choose Your Style</h3>
          <div className="grid grid-cols-2 gap-4">
            {styles.map((s) => (
              <button
                key={s.id}
                onClick={() => handleStyleSelect(s.id)}
                className={`flex items-start gap-3 rounded-2xl border p-5 text-left transition-all duration-300 hover:border-primary/50 hover:bg-card ${
                  selectedStyle === s.id ? "border-primary bg-primary/10" : "border-border"
                }`}
              >
                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary">
                  <s.icon className="h-5 w-5" />
                </div>
                <div>
                  <p className="font-display font-semibold">{s.label}</p>
                  <p className="text-sm text-muted-foreground">{s.desc}</p>
                </div>
              </button>
            ))}
          </div>
        </motion.div>
      )}

      {step === "processing" && (
        <ProcessingScreen onComplete={() => {}} label="Creating your professional headshots..." duration={30000} />
      )}

      {step === "result" && (
        <ResultGallery images={results} originalImage={uploadedImage || undefined} onRegenerate={handleReset} />
      )}

      <AdGateModal
        open={showAdGate}
        onClose={() => setShowAdGate(false)}
        onComplete={handleAdComplete}
        adCount={1}
        title="Watch Ad to Use Premium Tool"
        subtitle="Watch a 15s ad to unlock AI Corporate Headshots"
      />
    </FeatureLayout>
  );
};

export default HeadshotGenerator;
