import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { useNavigate } from "react-router-dom";
import { Camera, Package, Eraser, ZoomIn, Shirt, Download, LogOut, ImageIcon, Clock, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import Logo from "@/components/Logo";

interface ProfileData {
  display_name: string | null;
  avatar_url: string | null;
  credits: number;
  total_generations: number;
  created_at: string;
}

interface Generation {
  id: string;
  feature: string;
  result_url: string | null;
  created_at: string;
  status: string;
}

const featureIcons: Record<string, typeof Camera> = {
  headshot: Camera,
  product: Package,
  eraser: Eraser,
  upscale: ZoomIn,
  outfit: Shirt,
};

const featureLabels: Record<string, string> = {
  headshot: "AI Headshot",
  product: "Product Photo",
  eraser: "Magic Eraser",
  upscale: "18K Enhance",
  outfit: "Outfit Changer",
};

const featureColors: Record<string, string> = {
  headshot: "from-primary/20 to-primary/5",
  product: "from-accent/20 to-accent/5",
  eraser: "from-destructive/20 to-destructive/5",
  upscale: "from-primary/30 to-primary/5",
  outfit: "from-secondary/30 to-secondary/5",
};

const Profile = () => {
  const { user, signOut } = useAuth();
  const navigate = useNavigate();
  const [profile, setProfile] = useState<ProfileData | null>(null);
  const [generations, setGenerations] = useState<Generation[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeFilter, setActiveFilter] = useState<string>("all");

  useEffect(() => {
    if (!user) return;

    const fetchData = async () => {
      setLoading(true);

      const [profileRes, genRes] = await Promise.all([
        supabase.from("profiles").select("*").eq("user_id", user.id).single(),
        supabase
          .from("generations")
          .select("*")
          .eq("user_id", user.id)
          .order("created_at", { ascending: false }),
      ]);

      if (profileRes.data) setProfile(profileRes.data);
      if (genRes.data) setGenerations(genRes.data);
      setLoading(false);
    };

    fetchData();
  }, [user]);

  const filteredGenerations =
    activeFilter === "all"
      ? generations
      : generations.filter((g) => g.feature === activeFilter);

  const completedGenerations = generations.filter((g) => g.result_url);

  const handleDownload = (url: string, index: number) => {
    const a = document.createElement("a");
    a.href = url;
    a.download = `prostudio-ai-${index + 1}.jpg`;
    a.click();
  };

  const handleSignOut = async () => {
    await signOut();
    navigate("/");
  };

  const filters = [
    { id: "all", label: "All" },
    { id: "headshot", label: "Headshots" },
    { id: "product", label: "Products" },
    { id: "upscale", label: "Enhanced" },
    { id: "eraser", label: "Erased" },
    { id: "outfit", label: "Outfits" },
  ];

  const memberSince = profile?.created_at
    ? new Date(profile.created_at).toLocaleDateString("en-US", {
        month: "long",
        year: "numeric",
      })
    : "";

  const avatarUrl =
    profile?.avatar_url ||
    user?.user_metadata?.avatar_url ||
    user?.user_metadata?.picture;

  const displayName =
    profile?.display_name ||
    user?.user_metadata?.full_name ||
    user?.user_metadata?.name ||
    user?.email?.split("@")[0] ||
    "User";

  return (
    <div className="min-h-screen bg-background">
      {/* Nav */}
      <nav className="fixed top-0 z-50 w-full border-b border-border/50 bg-background/80 backdrop-blur-xl safe-top">
        <div className="container mx-auto flex h-14 items-center justify-between px-4">
          <Logo size="sm" />
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="sm" onClick={() => navigate("/")} className="touch-target">
              Home
            </Button>
            <Button variant="ghost" size="sm" onClick={handleSignOut} className="gap-1.5 text-destructive hover:text-destructive touch-target">
              <LogOut className="h-4 w-4" /> Sign Out
            </Button>
          </div>
        </div>
      </nav>

      <div className="pt-20 pb-16 px-4 safe-top safe-bottom">
        <div className="container mx-auto max-w-5xl">
          {/* Profile Header */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="relative rounded-2xl border border-border bg-card overflow-hidden mb-6"
          >
            <div className="h-24 bg-gradient-to-r from-primary/20 via-primary/10 to-accent/10" />
            <div className="px-4 pb-4 -mt-10">
              <div className="flex items-end gap-3">
                <div className="relative">
                  <div className="h-20 w-20 rounded-2xl border-4 border-card overflow-hidden bg-muted shadow-lg">
                    {avatarUrl ? (
                      <img src={avatarUrl} alt={displayName} className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center bg-primary/10 text-primary font-display text-2xl font-bold">
                        {displayName.charAt(0).toUpperCase()}
                      </div>
                    )}
                  </div>
                  <div className="absolute -bottom-1 -right-1 h-5 w-5 rounded-full bg-primary flex items-center justify-center">
                    <Sparkles className="h-2.5 w-2.5 text-primary-foreground" />
                  </div>
                </div>
                <div className="flex-1 min-w-0">
                  <h1 className="font-display text-xl font-bold truncate">{displayName}</h1>
                  <p className="text-muted-foreground text-xs truncate">{user?.email}</p>
                </div>
                <div className="text-center">
                  <p className="font-display text-xl font-bold">{completedGenerations.length}</p>
                  <p className="text-[10px] text-muted-foreground">Photos</p>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Stats */}
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="grid grid-cols-3 gap-2 mb-6"
          >
            <div className="rounded-xl border border-border bg-card p-3 flex items-center gap-2">
              <div className="h-8 w-8 rounded-lg bg-primary/10 flex items-center justify-center text-primary">
                <ImageIcon className="h-4 w-4" />
              </div>
              <div>
                <p className="text-sm font-semibold">{completedGenerations.length}</p>
                <p className="text-[10px] text-muted-foreground">Photos</p>
              </div>
            </div>
            <div className="rounded-xl border border-border bg-card p-3 flex items-center gap-2">
              <div className="h-8 w-8 rounded-lg bg-primary/10 flex items-center justify-center text-primary">
                <Clock className="h-4 w-4" />
              </div>
              <div>
                <p className="text-xs font-semibold">{memberSince}</p>
                <p className="text-[10px] text-muted-foreground">Joined</p>
              </div>
            </div>
            <div className="rounded-xl border border-border bg-card p-3 flex items-center gap-2">
              <div className="h-8 w-8 rounded-lg bg-primary/10 flex items-center justify-center text-primary">
                <Sparkles className="h-4 w-4" />
              </div>
              <div>
                <p className="text-xs font-semibold">Ad-Free</p>
                <p className="text-[10px] text-muted-foreground">Plan</p>
              </div>
            </div>
          </motion.div>

          {/* Gallery */}
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
          >
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-display text-xl font-bold">My Gallery</h2>
              <p className="text-xs text-muted-foreground">{filteredGenerations.length} items</p>
            </div>

            {/* Filter Tabs */}
            <div className="flex gap-2 overflow-x-auto pb-3 mb-4 scrollbar-hide">
              {filters.map((f) => (
                <button
                  key={f.id}
                  onClick={() => setActiveFilter(f.id)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-all touch-target ${
                    activeFilter === f.id
                      ? "bg-primary text-primary-foreground shadow-md"
                      : "bg-card border border-border text-muted-foreground hover:text-foreground hover:border-primary/30"
                  }`}
                >
                  {f.label}
                </button>
              ))}
            </div>

            {/* Gallery Grid */}
            {loading ? (
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
                {Array.from({ length: 8 }).map((_, i) => (
                  <div key={i} className="rounded-2xl bg-muted animate-pulse aspect-[3/4]" />
                ))}
              </div>
            ) : filteredGenerations.length === 0 ? (
              <div className="text-center py-16 rounded-2xl border border-dashed border-border">
                <div className="h-14 w-14 rounded-2xl bg-primary/10 flex items-center justify-center mx-auto mb-3 text-primary">
                  <ImageIcon className="h-7 w-7" />
                </div>
                <h3 className="font-display text-lg font-semibold mb-1.5">No photos yet</h3>
                <p className="text-muted-foreground text-sm mb-4">
                  Start creating amazing AI photos
                </p>
                <Button variant="hero" onClick={() => navigate("/headshot")} className="touch-target">
                  Create Your First Photo
                </Button>
              </div>
            ) : (
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
                {filteredGenerations.map((gen, i) => {
                  const FeatureIcon = featureIcons[gen.feature] || Sparkles;
                  return (
                    <motion.div
                      key={gen.id}
                      initial={{ opacity: 0, scale: 0.9 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ delay: i * 0.05 }}
                      className="group relative rounded-2xl border border-border overflow-hidden bg-card cursor-pointer hover:border-primary/30 hover:shadow-gold transition-all duration-300 active:scale-[0.97]"
                    >
                      {gen.result_url ? (
                        <img
                          src={gen.result_url}
                          alt={`${featureLabels[gen.feature] || gen.feature} result`}
                          className="w-full aspect-[3/4] object-cover"
                          loading="lazy"
                        />
                      ) : (
                        <div className={`w-full aspect-[3/4] bg-gradient-to-br ${featureColors[gen.feature] || "from-muted to-muted/50"} flex items-center justify-center`}>
                          <FeatureIcon className="h-10 w-10 text-muted-foreground/50" />
                        </div>
                      )}

                      {/* Overlay */}
                      <div className="absolute inset-0 bg-gradient-to-t from-background/90 via-background/20 to-transparent opacity-0 group-hover:opacity-100 transition-all duration-300 flex flex-col justify-end p-3">
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="text-xs font-semibold text-foreground">{featureLabels[gen.feature] || gen.feature}</p>
                            <p className="text-[10px] text-muted-foreground">
                              {new Date(gen.created_at).toLocaleDateString()}
                            </p>
                          </div>
                          {gen.result_url && (
                            <Button
                              size="icon"
                              variant="ghost"
                              className="h-8 w-8 rounded-full bg-primary/20 hover:bg-primary/40 text-primary"
                              onClick={(e) => {
                                e.stopPropagation();
                                handleDownload(gen.result_url!, i);
                              }}
                            >
                              <Download className="h-3.5 w-3.5" />
                            </Button>
                          )}
                        </div>
                      </div>

                      {/* Feature Badge */}
                      <div className="absolute top-2 left-2">
                        <div className="flex items-center gap-1 px-1.5 py-0.5 rounded-full bg-background/80 backdrop-blur-sm text-[9px] font-semibold text-primary border border-primary/20">
                          <FeatureIcon className="h-2.5 w-2.5" />
                          {featureLabels[gen.feature] || gen.feature}
                        </div>
                      </div>

                      {gen.status !== "completed" && (
                        <div className="absolute top-2 right-2">
                          <span className="px-1.5 py-0.5 rounded-full bg-muted text-[9px] font-medium text-muted-foreground">
                            {gen.status}
                          </span>
                        </div>
                      )}
                    </motion.div>
                  );
                })}
              </div>
            )}
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default Profile;
