import { useState, useCallback } from "react";
import { motion } from "framer-motion";
import FeatureLayout from "@/components/FeatureLayout";
import UploadZone from "@/components/UploadZone";
import ProcessingScreen from "@/components/ProcessingScreen";
import ResultGallery from "@/components/ResultGallery";
import AdGateModal from "@/components/AdGateModal";
import { useAiGenerate } from "@/hooks/useAiGenerate";

type Step = "upload" | "template" | "processing" | "result";

const templates = [
  { id: "marble", label: "Marble Studio", emoji: "🪨", desc: "Clean marble podium with soft shadows" },
  { id: "wooden", label: "Wooden Table", emoji: "🪵", desc: "Warm wooden surface with natural light" },
  { id: "water", label: "Water Splash", emoji: "💧", desc: "Dynamic water splash effect" },
  { id: "outdoor", label: "Outdoor Sunlight", emoji: "☀️", desc: "Natural outdoor setting with bokeh" },
];

const ProductPhotoshoot = () => {
  const [step, setStep] = useState<Step>("upload");
  const [uploadedImage, setUploadedImage] = useState<string | null>(null);
  const [showAdGate, setShowAdGate] = useState(false);
  const [pendingTemplate, setPendingTemplate] = useState<string | null>(null);
  const { generate, results, reset: resetAi } = useAiGenerate();

  const handleUpload = useCallback((files: File[]) => {
    setUploadedImage(URL.createObjectURL(files[0]));
    setStep("template");
  }, []);

  const toBase64 = (url: string): Promise<string> =>
    fetch(url).then((r) => r.blob()).then(
      (blob) => new Promise((resolve) => {
        const reader = new FileReader();
        reader.onloadend = () => resolve(reader.result as string);
        reader.readAsDataURL(blob);
      })
    );

  const handleTemplateSelect = (templateId: string) => {
    setPendingTemplate(templateId);
    setShowAdGate(true);
  };

  const handleAdComplete = async () => {
    setShowAdGate(false);
    if (!pendingTemplate) return;
    setStep("processing");

    let imageBase64: string | undefined;
    if (uploadedImage) imageBase64 = await toBase64(uploadedImage);

    const imgs = await generate({
      feature: "product",
      options: { template: pendingTemplate },
      imageBase64,
    });

    if (imgs.length > 0) {
      setStep("result");
    } else {
      setStep("template");
    }
  };

  const handleReset = () => {
    setStep("upload");
    setUploadedImage(null);
    resetAi();
  };

  return (
    <FeatureLayout
      title="AI Product Photoshoot"
      subtitle="Drop your product photo → Watch ad → Get stunning e-commerce visuals instantly"
    >
      {step === "upload" && (
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
          <UploadZone onFileSelect={handleUpload} label="Upload your product photo" sublabel="Any angle works • AI removes background automatically" />
        </motion.div>
      )}

      {step === "template" && (
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
          {uploadedImage && (
            <div className="flex justify-center">
              <div className="w-32 h-32 rounded-2xl overflow-hidden border border-primary/30">
                <img src={uploadedImage} alt="Product" className="w-full h-full object-cover" />
              </div>
            </div>
          )}
          <h3 className="font-display text-xl font-semibold text-center">Choose Scene Template</h3>
          <div className="grid grid-cols-2 gap-4">
            {templates.map((t) => (
              <button
                key={t.id}
                onClick={() => handleTemplateSelect(t.id)}
                className="flex items-start gap-3 rounded-2xl border border-border p-5 text-left transition-all duration-300 hover:border-primary/50 hover:bg-card"
              >
                <span className="text-3xl">{t.emoji}</span>
                <div>
                  <p className="font-display font-semibold">{t.label}</p>
                  <p className="text-sm text-muted-foreground">{t.desc}</p>
                </div>
              </button>
            ))}
          </div>
        </motion.div>
      )}

      {step === "processing" && (
        <ProcessingScreen onComplete={() => {}} label="Creating product visuals..." duration={30000} />
      )}

      {step === "result" && (
        <ResultGallery images={results} originalImage={uploadedImage || undefined} onRegenerate={handleReset} />
      )}

      <AdGateModal
        open={showAdGate}
        onClose={() => setShowAdGate(false)}
        onComplete={handleAdComplete}
        adCount={1}
        title="Watch Ad to Use Premium Tool"
        subtitle="Watch a 15s ad to unlock AI Product Photoshoot"
      />
    </FeatureLayout>
  );
};

export default ProductPhotoshoot;
