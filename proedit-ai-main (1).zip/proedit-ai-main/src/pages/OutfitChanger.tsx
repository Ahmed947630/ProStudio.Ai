import { useState, useCallback } from "react";
import { motion } from "framer-motion";
import { Shirt, Scissors } from "lucide-react";
import FeatureLayout from "@/components/FeatureLayout";
import UploadZone from "@/components/UploadZone";
import ProcessingScreen from "@/components/ProcessingScreen";
import ResultGallery from "@/components/ResultGallery";
import AdGateModal from "@/components/AdGateModal";
import { useAiGenerate } from "@/hooks/useAiGenerate";

type Step = "upload" | "options" | "processing" | "result";
type Mode = "outfit" | "hairstyle";

const outfitOptions = [
  { id: "blue-suit", label: "Blue Suit", emoji: "👔" },
  { id: "black-blazer", label: "Black Blazer", emoji: "🖤" },
  { id: "white-shirt", label: "White Formal Shirt", emoji: "👕" },
  { id: "casual-jacket", label: "Casual Jacket", emoji: "🧥" },
];

const hairstyleOptions = [
  { id: "short", label: "Short Hair", emoji: "💇" },
  { id: "curly", label: "Curly Hair", emoji: "🌀" },
  { id: "slick", label: "Slick Back", emoji: "✨" },
  { id: "buzz", label: "Buzz Cut", emoji: "⚡" },
];

const OutfitChanger = () => {
  const [step, setStep] = useState<Step>("upload");
  const [mode, setMode] = useState<Mode>("outfit");
  const [uploadedImage, setUploadedImage] = useState<string | null>(null);
  const [showAdGate, setShowAdGate] = useState(false);
  const [pendingOption, setPendingOption] = useState<string | null>(null);
  const { generate, results, reset: resetAi } = useAiGenerate();

  const handleUpload = useCallback((files: File[]) => {
    setUploadedImage(URL.createObjectURL(files[0]));
    setStep("options");
  }, []);

  const toBase64 = (url: string): Promise<string> =>
    fetch(url).then((r) => r.blob()).then(
      (blob) => new Promise((resolve) => {
        const reader = new FileReader();
        reader.onloadend = () => resolve(reader.result as string);
        reader.readAsDataURL(blob);
      })
    );

  const handleOptionSelect = (optionId: string) => {
    setPendingOption(optionId);
    setShowAdGate(true);
  };

  const handleAdComplete = async () => {
    setShowAdGate(false);
    if (!pendingOption) return;
    setStep("processing");

    let imageBase64: string | undefined;
    if (uploadedImage) imageBase64 = await toBase64(uploadedImage);

    const imgs = await generate({
      feature: "outfit",
      options: { option: pendingOption, mode },
      imageBase64,
    });

    if (imgs.length > 0) {
      setStep("result");
    } else {
      setStep("options");
    }
  };

  const handleReset = () => {
    setStep("upload");
    setUploadedImage(null);
    resetAi();
  };

  const options = mode === "outfit" ? outfitOptions : hairstyleOptions;

  return (
    <FeatureLayout
      title="Outfit & Hairstyle Changer"
      subtitle="See how you look in different outfits and hairstyles — AI-powered virtual try-on"
    >
      {step === "upload" && (
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
          <div className="flex justify-center gap-4">
            {[
              { m: "outfit" as Mode, icon: Shirt, label: "Change Outfit" },
              { m: "hairstyle" as Mode, icon: Scissors, label: "Change Hairstyle" },
            ].map((opt) => (
              <button
                key={opt.m}
                onClick={() => setMode(opt.m)}
                className={`flex items-center gap-2 rounded-xl border px-6 py-3 font-display font-semibold transition-all ${
                  mode === opt.m ? "border-primary bg-primary/10 text-primary" : "border-border text-muted-foreground hover:border-primary/30"
                }`}
              >
                <opt.icon className="h-5 w-5" />
                {opt.label}
              </button>
            ))}
          </div>
          <UploadZone onFileSelect={handleUpload} label="Upload your full-body or portrait photo" sublabel="Clear, well-lit photos work best" />
        </motion.div>
      )}

      {step === "options" && (
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
          {uploadedImage && (
            <div className="flex justify-center">
              <div className="w-32 h-40 rounded-2xl overflow-hidden border border-primary/30">
                <img src={uploadedImage} alt="Your photo" className="w-full h-full object-cover" />
              </div>
            </div>
          )}
          <h3 className="font-display text-xl font-semibold text-center">
            Choose {mode === "outfit" ? "Outfit" : "Hairstyle"}
          </h3>
          <div className="grid grid-cols-2 gap-4">
            {options.map((opt) => (
              <button
                key={opt.id}
                onClick={() => handleOptionSelect(opt.id)}
                className="flex items-center gap-3 rounded-2xl border border-border p-5 text-left transition-all duration-300 hover:border-primary/50 hover:bg-card"
              >
                <span className="text-3xl">{opt.emoji}</span>
                <p className="font-display font-semibold">{opt.label}</p>
              </button>
            ))}
          </div>
        </motion.div>
      )}

      {step === "processing" && (
        <ProcessingScreen onComplete={() => {}} label={`Applying ${mode === "outfit" ? "outfit" : "hairstyle"} change...`} duration={30000} />
      )}

      {step === "result" && (
        <ResultGallery images={results} originalImage={uploadedImage || undefined} onRegenerate={handleReset} />
      )}

      <AdGateModal
        open={showAdGate}
        onClose={() => setShowAdGate(false)}
        onComplete={handleAdComplete}
        adCount={1}
        title="Watch Ad to Use Premium Tool"
        subtitle="Watch a 15s ad to unlock Outfit & Hairstyle Changer"
      />
    </FeatureLayout>
  );
};

export default OutfitChanger;
