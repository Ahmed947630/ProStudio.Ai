import { motion } from "framer-motion";
import { Camera, Package, Eraser, ZoomIn, ArrowRight, ChevronDown, Shirt, Sparkles, User, Expand, Crown, Lock } from "lucide-react";
import Logo from "@/components/Logo";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import heroImage from "@/assets/hero-image.jpg";
import productShowcase from "@/assets/product-showcase.jpg";
import enhanceShowcase from "@/assets/enhance-showcase.jpg";

const fadeUp = {
  hidden: { opacity: 0, y: 30 },
  visible: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: { delay: i * 0.15, duration: 0.6, ease: "easeOut" as const },
  }),
};

const features = [
  {
    icon: Camera,
    title: "AI Corporate Headshots",
    desc: "Upload 1-3 selfies. Get studio-quality LinkedIn headshots in seconds.",
    image: heroImage,
    tag: "⭐ Star Feature",
    route: "/headshot",
    gradient: "from-primary/20 to-primary/5",
    premium: true,
  },
  {
    icon: Package,
    title: "AI Product Photoshoot",
    desc: "Drop your product photo. AI creates stunning e-commerce visuals.",
    image: productShowcase,
    tag: "E-Commerce",
    route: "/product",
    gradient: "from-accent/20 to-accent/5",
    premium: true,
  },
  {
    icon: Shirt,
    title: "Outfit & Hairstyle Changer",
    desc: "Virtual try-on with realistic AI fabric & texture rendering.",
    image: productShowcase,
    tag: "Fashion",
    route: "/outfit",
    gradient: "from-secondary/40 to-secondary/10",
    premium: true,
  },
  {
    icon: Eraser,
    title: "Magic Eraser & Cleanup",
    desc: "Remove unwanted people, wires, or clutter using AI inpainting.",
    image: enhanceShowcase,
    tag: "Free Tool",
    route: "/eraser",
    gradient: "from-muted/40 to-muted/10",
    premium: false,
  },
  {
    icon: ZoomIn,
    title: "18K AI Enhance",
    desc: "Transform blurry photos to crystal-clear 18K ultra HD quality.",
    image: enhanceShowcase,
    tag: "Free Tool",
    route: "/upscale",
    gradient: "from-primary/20 to-primary/5",
    premium: false,
  },
  {
    icon: Expand,
    title: "AI Expand & Uncrop",
    desc: "Extend your image canvas with AI-generated content in any direction.",
    image: enhanceShowcase,
    tag: "Free Tool",
    route: "/expand",
    gradient: "from-accent/20 to-accent/5",
    premium: false,
  },
];

const Index = () => {
  const navigate = useNavigate();
  const { user } = useAuth();

  return (
    <div className="min-h-screen bg-background overflow-x-hidden">
      {/* Nav */}
      <nav className="fixed top-0 z-50 w-full border-b border-border/50 bg-background/80 backdrop-blur-xl safe-top">
        <div className="container mx-auto flex h-14 items-center justify-between px-4">
          <Logo size="sm" />
          <div className="flex items-center gap-2">
            {user && (
              <Button variant="ghost" size="sm" onClick={() => navigate("/profile")} className="gap-1.5 touch-target">
                <User className="h-4 w-4" /> Gallery
              </Button>
            )}
            <Button variant="hero" size="sm" onClick={() => user ? navigate("/profile") : navigate("/headshot")} className="touch-target">
              {user ? "Dashboard" : "Get Started"}
            </Button>
          </div>
        </div>
      </nav>

      {/* Hero */}
      <section className="relative pt-24 pb-16 px-4 safe-top">
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-[400px] h-[400px] rounded-full bg-primary/5 blur-[100px]" />
        </div>
        <div className="container mx-auto relative">
          <motion.div
            className="text-center max-w-4xl mx-auto"
            initial="hidden"
            animate="visible"
          >
            <motion.div variants={fadeUp} custom={0} className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full border border-gold bg-primary/5 text-primary text-xs font-medium mb-6">
              <Sparkles className="h-3.5 w-3.5" />
              AI-Powered Professional Photography
            </motion.div>

            <motion.h1 variants={fadeUp} custom={1} className="font-display text-4xl md:text-7xl font-bold leading-tight mb-4">
              Your Selfie.{" "}
              <span className="text-gradient-gold">Studio Quality.</span>
            </motion.h1>

            <motion.p variants={fadeUp} custom={2} className="text-base md:text-xl text-muted-foreground max-w-2xl mx-auto mb-8">
              Transform casual selfies into professional headshots and stunning product photos — all powered by AI.
            </motion.p>

            <motion.div variants={fadeUp} custom={3} className="flex flex-col sm:flex-row gap-3 justify-center">
              <Button variant="hero" size="lg" className="text-base px-8 touch-target" onClick={() => navigate("/headshot")}>
                Start Creating <ArrowRight className="ml-1 h-5 w-5" />
              </Button>
              <Button variant="hero-outline" size="lg" className="text-base px-8 touch-target" onClick={() => navigate("/product")}>
                See Examples
              </Button>
            </motion.div>
          </motion.div>

          {/* Hero Image */}
          <motion.div
            variants={fadeUp}
            custom={4}
            initial="hidden"
            animate="visible"
            className="mt-12 max-w-5xl mx-auto"
          >
            <div className="relative rounded-2xl overflow-hidden shadow-gold-lg border border-border">
              <img src={heroImage} alt="AI headshot transformation — selfie to professional photo" className="w-full" loading="lazy" />
              <div className="absolute inset-0 bg-gradient-to-t from-background/60 via-transparent to-transparent" />
              <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between">
                <span className="text-xs text-muted-foreground">Selfie → Professional Headshot in 10s</span>
                <span className="inline-flex items-center gap-1 text-xs text-primary font-medium">
                  <Sparkles className="h-3 w-3" /> AI Generated
                </span>
              </div>
            </div>
          </motion.div>

          <motion.div variants={fadeUp} custom={5} initial="hidden" animate="visible" className="flex justify-center mt-8">
            <a href="#features">
              <ChevronDown className="h-6 w-6 text-muted-foreground animate-bounce" />
            </a>
          </motion.div>
        </div>
      </section>

      {/* Features */}
      <section id="features" className="py-16 px-4">
        <div className="container mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="font-display text-3xl md:text-5xl font-bold mb-3">
              Everything You Need
            </h2>
            <p className="text-muted-foreground text-base max-w-xl mx-auto">
              Professional-grade AI tools — some free, some premium with ad-supported access.
            </p>
          </motion.div>

          {/* Premium Tools */}
          <div className="mb-8">
            <div className="flex items-center gap-2 mb-5">
              <Crown className="h-5 w-5 text-primary" />
              <h3 className="font-display text-xl font-bold">Premium Tools</h3>
              <span className="px-2.5 py-0.5 rounded-full bg-primary/10 text-primary text-xs font-bold border border-primary/20">Ad to Unlock</span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 max-w-6xl mx-auto">
              {features.filter(f => f.premium).map((f, i) => (
                <motion.div
                  key={f.title}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 }}
                  onClick={() => navigate(f.route)}
                  className="group relative rounded-2xl border border-primary/30 bg-card overflow-hidden cursor-pointer hover:border-primary/60 hover:shadow-gold transition-all duration-500 active:scale-[0.98]"
                >
                  <div className="relative h-44 overflow-hidden">
                    <img src={f.image} alt={f.title} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" loading="lazy" />
                    <div className="absolute inset-0 bg-gradient-to-t from-card via-card/40 to-transparent" />
                    <div className="absolute top-3 left-3">
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-primary/90 backdrop-blur-sm text-[10px] font-bold text-primary-foreground">
                        <Crown className="h-2.5 w-2.5" /> Premium
                      </span>
                    </div>
                    <div className="absolute top-3 right-3">
                      <div className="flex h-8 w-8 items-center justify-center rounded-full bg-background/80 backdrop-blur-sm text-primary border border-primary/20">
                        <f.icon className="h-3.5 w-3.5" />
                      </div>
                    </div>
                  </div>
                  <div className="p-4">
                    <h3 className="font-display text-base font-bold mb-1.5 group-hover:text-primary transition-colors">{f.title}</h3>
                    <p className="text-muted-foreground text-sm leading-relaxed mb-3 line-clamp-2">{f.desc}</p>
                    <div className="flex items-center gap-1 text-sm text-primary font-semibold group-hover:gap-2 transition-all">
                      <Lock className="h-3.5 w-3.5" /> Watch Ad & Try <ArrowRight className="h-4 w-4" />
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>

          {/* Free Tools */}
          <div>
            <div className="flex items-center gap-2 mb-5">
              <Sparkles className="h-5 w-5 text-accent" />
              <h3 className="font-display text-xl font-bold">Free Tools</h3>
              <span className="px-2.5 py-0.5 rounded-full bg-accent/10 text-accent text-xs font-bold border border-accent/20">No Limits</span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 max-w-6xl mx-auto">
              {features.filter(f => !f.premium).map((f, i) => (
                <motion.div
                  key={f.title}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 }}
                  onClick={() => navigate(f.route)}
                  className="group relative rounded-2xl border border-border bg-card overflow-hidden cursor-pointer hover:border-accent/40 hover:shadow-gold transition-all duration-500 active:scale-[0.98]"
                >
                  <div className="relative h-44 overflow-hidden">
                    <img src={f.image} alt={f.title} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" loading="lazy" />
                    <div className="absolute inset-0 bg-gradient-to-t from-card via-card/40 to-transparent" />
                    <div className="absolute top-3 left-3">
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-accent/90 backdrop-blur-sm text-[10px] font-bold text-primary-foreground">
                        <Sparkles className="h-2.5 w-2.5" /> Free
                      </span>
                    </div>
                    <div className="absolute top-3 right-3">
                      <div className="flex h-8 w-8 items-center justify-center rounded-full bg-background/80 backdrop-blur-sm text-accent border border-accent/20">
                        <f.icon className="h-3.5 w-3.5" />
                      </div>
                    </div>
                  </div>
                  <div className="p-4">
                    <h3 className="font-display text-base font-bold mb-1.5 group-hover:text-accent transition-colors">{f.title}</h3>
                    <p className="text-muted-foreground text-sm leading-relaxed mb-3 line-clamp-2">{f.desc}</p>
                    <div className="flex items-center gap-1 text-sm text-accent font-semibold group-hover:gap-2 transition-all">
                      Try Free <ArrowRight className="h-4 w-4" />
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-16 px-4 border-t border-border">
        <div className="container mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="font-display text-3xl md:text-5xl font-bold mb-3">
              How It <span className="text-gradient-gold">Works</span>
            </h2>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto">
            {[
              { step: "01", title: "Upload", desc: "Take a selfie or upload your product photo" },
              { step: "02", title: "AI Processes", desc: "Our AI transforms your photo in 10-20 seconds" },
              { step: "03", title: "Watch & Download", desc: "Watch a short ad and download your results" },
            ].map((s, i) => (
              <motion.div
                key={s.step}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.15 }}
                className="text-center"
              >
                <div className="inline-flex items-center justify-center w-14 h-14 rounded-full bg-primary/10 text-primary font-display text-xl font-bold mb-3">
                  {s.step}
                </div>
                <h3 className="font-display text-lg font-semibold mb-1.5">{s.title}</h3>
                <p className="text-muted-foreground text-sm">{s.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border py-8 px-4 safe-bottom">
        <div className="container mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
          <Logo size="sm" clickable={false} />
          <div className="flex items-center gap-4">
            <a href="/privacy" onClick={(e) => { e.preventDefault(); navigate("/privacy"); }} className="text-muted-foreground hover:text-primary text-xs transition-colors">Privacy Policy</a>
            <a href="/terms" onClick={(e) => { e.preventDefault(); navigate("/terms"); }} className="text-muted-foreground hover:text-primary text-xs transition-colors">Terms of Service</a>
          </div>
          <p className="text-muted-foreground text-xs">
            © 2026 ProStudio AI. All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  );
};

export default Index;
