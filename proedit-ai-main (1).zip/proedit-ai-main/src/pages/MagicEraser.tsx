import { useState, useCallback } from "react";
import { motion } from "framer-motion";
import FeatureLayout from "@/components/FeatureLayout";
import UploadZone from "@/components/UploadZone";
import ProcessingScreen from "@/components/ProcessingScreen";
import ResultGallery from "@/components/ResultGallery";
import { useAiGenerate } from "@/hooks/useAiGenerate";

type Step = "upload" | "edit" | "processing" | "result";

const MagicEraser = () => {
  const [step, setStep] = useState<Step>("upload");
  const [uploadedImage, setUploadedImage] = useState<string | null>(null);
  const { generate, results, reset: resetAi } = useAiGenerate();

  const handleUpload = useCallback((files: File[]) => {
    setUploadedImage(URL.createObjectURL(files[0]));
    setStep("edit");
  }, []);

  const toBase64 = (url: string): Promise<string> =>
    fetch(url).then((r) => r.blob()).then(
      (blob) => new Promise((resolve) => {
        const reader = new FileReader();
        reader.onloadend = () => resolve(reader.result as string);
        reader.readAsDataURL(blob);
      })
    );

  const handleProcess = async () => {
    setStep("processing");
    let imageBase64: string | undefined;
    if (uploadedImage) imageBase64 = await toBase64(uploadedImage);

    const imgs = await generate({ feature: "eraser", imageBase64 });

    if (imgs.length > 0) {
      setStep("result");
    } else {
      setStep("edit");
    }
  };

  const handleReset = () => {
    setStep("upload");
    setUploadedImage(null);
    resetAi();
  };

  return (
    <FeatureLayout
      title="Magic Eraser & Cleanup"
      subtitle="Remove unwanted objects, people, or clutter from any photo using AI — Free!"
    >
      {step === "upload" && (
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
          <UploadZone onFileSelect={handleUpload} label="Upload a photo to clean up" sublabel="Remove people, wires, text, or any unwanted objects" />
        </motion.div>
      )}

      {step === "edit" && (
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
          <div className="relative rounded-2xl overflow-hidden border border-border bg-card">
            {uploadedImage && (
              <img src={uploadedImage} alt="Your photo" className="w-full max-h-[500px] object-contain" />
            )}
            <div className="absolute inset-0 flex items-center justify-center bg-background/40">
              <div className="text-center space-y-3 p-6 rounded-2xl bg-background/80 border border-border backdrop-blur-sm">
                <p className="font-display text-lg font-semibold">Brush over areas to remove</p>
                <p className="text-sm text-muted-foreground">AI will analyze and clean up the photo</p>
                <button
                  onClick={handleProcess}
                  className="mt-2 inline-flex items-center gap-2 rounded-xl bg-gradient-gold px-6 py-3 font-display font-semibold text-primary-foreground transition-all hover:scale-105"
                >
                  Process with AI ✨
                </button>
              </div>
            </div>
          </div>
        </motion.div>
      )}

      {step === "processing" && (
        <ProcessingScreen onComplete={() => {}} label="Removing unwanted objects..." duration={30000} />
      )}

      {step === "result" && (
        <ResultGallery images={results} originalImage={uploadedImage || undefined} onRegenerate={handleReset} />
      )}
    </FeatureLayout>
  );
};

export default MagicEraser;
