import { ArrowLeft } from "lucide-react";
import { Link } from "react-router-dom";

const TermsOfService = () => {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <div className="max-w-3xl mx-auto px-4 py-8 safe-top safe-bottom">
        <Link to="/" className="inline-flex items-center gap-2 text-muted-foreground hover:text-primary mb-8 transition-colors">
          <ArrowLeft className="h-4 w-4" />
          Back to Home
        </Link>

        <h1 className="font-display text-3xl font-bold mb-2">Terms of Service</h1>
        <p className="text-muted-foreground mb-8">Last updated: March 8, 2026</p>

        <div className="prose prose-invert max-w-none space-y-6 text-muted-foreground">
          <section>
            <h2 className="text-xl font-semibold text-foreground">1. Acceptance of Terms</h2>
            <p>By downloading, installing, or using Pro Studio AI ("the App"), you agree to be bound by these Terms of Service. If you do not agree to these terms, do not use the App.</p>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-foreground">2. Description of Service</h2>
            <p>Pro Studio AI provides AI-powered image editing and generation tools, including but not limited to:</p>
            <ul className="list-disc pl-6 space-y-2">
              <li>AI Headshot Generation</li>
              <li>Product Photography Enhancement</li>
              <li>Background Removal (Magic Eraser)</li>
              <li>Image Upscaling</li>
              <li>AI Image Expansion (Uncrop)</li>
              <li>Virtual Outfit & Hairstyle Changing</li>
            </ul>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-foreground">3. User Accounts</h2>
            <p>You must create an account to access the App's features. You are responsible for maintaining the confidentiality of your account credentials and for all activities that occur under your account.</p>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-foreground">4. Credits & Usage</h2>
            <ul className="list-disc pl-6 space-y-2">
              <li>The App operates on a credit-based system. Each AI generation consumes credits.</li>
              <li>Free credits are provided upon account creation and may be replenished by watching advertisements.</li>
              <li>Credits are non-transferable and non-refundable.</li>
              <li>We reserve the right to modify the credit system at any time.</li>
            </ul>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-foreground">5. Advertisements</h2>
            <p>The App displays advertisements through Google AdMob. Some premium features require watching advertisements to unlock. By using the App, you consent to viewing advertisements as part of the service.</p>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-foreground">6. User Content</h2>
            <ul className="list-disc pl-6 space-y-2">
              <li>You retain ownership of images you upload to the App.</li>
              <li>You grant us a limited, temporary license to process your images for the purpose of providing our services.</li>
              <li>You are solely responsible for ensuring you have the right to use any images you upload.</li>
              <li>You must not upload illegal, harmful, or offensive content.</li>
            </ul>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-foreground">7. AI-Generated Content</h2>
            <p>AI-generated results are provided "as is." We do not guarantee the accuracy, quality, or suitability of AI-generated content. You are responsible for reviewing and using generated content appropriately.</p>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-foreground">8. Prohibited Uses</h2>
            <p>You agree not to:</p>
            <ul className="list-disc pl-6 space-y-2">
              <li>Use the App to create deepfakes or misleading content intended to deceive</li>
              <li>Generate explicit, harmful, or illegal content</li>
              <li>Attempt to reverse-engineer or exploit the App's AI systems</li>
              <li>Use automated systems to abuse the credit or ad-watching features</li>
              <li>Violate any applicable laws or regulations</li>
            </ul>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-foreground">9. Limitation of Liability</h2>
            <p>Pro Studio AI is provided "as is" without warranties of any kind. We shall not be liable for any indirect, incidental, special, or consequential damages arising from your use of the App.</p>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-foreground">10. Termination</h2>
            <p>We reserve the right to suspend or terminate your account at any time for violation of these terms or for any other reason at our sole discretion.</p>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-foreground">11. Changes to Terms</h2>
            <p>We may update these Terms of Service at any time. Continued use of the App after changes constitutes acceptance of the updated terms.</p>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-foreground">12. Contact</h2>
            <p>For questions about these Terms, contact us at: <a href="mailto:support@prostudioai.com" className="text-primary hover:underline">support@prostudioai.com</a></p>
          </section>
        </div>
      </div>
    </div>
  );
};

export default TermsOfService;
