
-- Create storage bucket for user uploads
INSERT INTO storage.buckets (id, name, public) VALUES ('uploads', 'uploads', false);

-- Create storage bucket for AI generated results  
INSERT INTO storage.buckets (id, name, public) VALUES ('results', 'results', true);

-- RLS policies for uploads bucket - users can upload their own files
CREATE POLICY "Anyone can upload to uploads" ON storage.objects
FOR INSERT WITH CHECK (bucket_id = 'uploads');

CREATE POLICY "Anyone can view their uploads" ON storage.objects
FOR SELECT USING (bucket_id = 'uploads');

-- RLS policies for results bucket - public read access
CREATE POLICY "Anyone can view results" ON storage.objects
FOR SELECT USING (bucket_id = 'results');

CREATE POLICY "Service role can insert results" ON storage.objects
FOR INSERT WITH CHECK (bucket_id = 'results');

-- Create generations table to track AI usage
CREATE TABLE public.generations (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  feature TEXT NOT NULL,
  input_prompt TEXT,
  status TEXT NOT NULL DEFAULT 'pending',
  result_url TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.generations ENABLE ROW LEVEL SECURITY;

-- Public insert/select for now (no auth yet)
CREATE POLICY "Anyone can create generations" ON public.generations
FOR INSERT WITH CHECK (true);

CREATE POLICY "Anyone can view generations" ON public.generations
FOR SELECT USING (true);

CREATE POLICY "Anyone can update generations" ON public.generations
FOR UPDATE USING (true);
