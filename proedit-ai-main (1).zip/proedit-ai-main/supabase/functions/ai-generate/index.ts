import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

const PROMPTS: Record<string, (opts: any) => string> = {
  headshot: (opts) =>
    `Generate a professional corporate headshot photo of a person. Style: ${opts.style || "corporate suit"}. The person should be in a studio setting with professional lighting, wearing a ${opts.style === "casual" ? "smart casual blazer" : opts.style === "academic" ? "academic professional attire" : opts.style === "executive" ? "premium executive suit" : "classic business suit"}. Background should be a clean, professional studio backdrop. The photo should look like a high-end LinkedIn profile picture. Ultra high quality, photorealistic.`,

  product: (opts) =>
    `Generate a professional e-commerce product photography scene. Template: ${opts.template || "marble"}. Show a product on a ${opts.template === "marble" ? "clean white marble podium with soft shadows and elegant studio lighting" : opts.template === "wooden" ? "warm wooden table surface with natural window light" : opts.template === "water" ? "dynamic water splash effect with dramatic lighting" : "natural outdoor setting with beautiful bokeh and sunlight"}. Ultra high quality, commercial photography style. 4K resolution look.`,

  eraser: () =>
    `Generate a clean, professionally edited photo where unwanted objects have been removed. The result should look natural with seamless background fill. Professional photo editing quality.`,

  upscale: (opts) => {
    const resolution = opts.resolution || "18K";
    const scaleInfo = opts.scale ? ` Scale: ${opts.scale}.` : "";
    const ratioInfo = opts.ratio ? ` Target aspect ratio: ${opts.ratio}.` : "";
    const promptInfo = opts.prompt ? ` Additional instructions: ${opts.prompt}.` : "";
    return opts.mode === "uncrop"
      ? `Generate a crystal clear, ultra high definition expanded photo. AI expand the canvas to show natural surrounding environment seamlessly.${scaleInfo}${ratioInfo}${promptInfo} The expansion should blend perfectly with the original image. Professional quality, ${resolution} resolution enhancement.`
      : `Generate a crystal clear, ultra high definition enhanced ${resolution} photo with extremely sharp details, restored faces, vivid true-to-life colors, and zero artifacts.${scaleInfo}${promptInfo} Professional quality enhancement.`;
  },

  outfit: (opts) =>
    `Generate a photo of a person wearing a ${opts.option || "blue suit"}. The clothing should look realistic with proper fabric texture and fit. ${opts.mode === "hairstyle" ? `Show the person with a ${opts.option || "short"} hairstyle that looks natural.` : ""} Professional fashion photography quality.`,
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) throw new Error("LOVABLE_API_KEY is not configured");

    const { feature, options, imageBase64 } = await req.json();

    if (!feature || !PROMPTS[feature]) {
      return new Response(
        JSON.stringify({ error: "Invalid feature. Use: headshot, product, eraser, upscale, outfit" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const prompt = PROMPTS[feature](options || {});

    // Build messages - include image if provided
    const userContent: any[] = [{ type: "text", text: prompt }];
    if (imageBase64) {
      userContent.push({
        type: "image_url",
        image_url: { url: imageBase64 },
      });
    }

    console.log(`Processing ${feature} generation...`);

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash-image",
        messages: [
          {
            role: "user",
            content: userContent,
          },
        ],
        modalities: ["image", "text"],
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(
          JSON.stringify({ error: "Rate limit exceeded. Please try again in a moment." }),
          { status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      if (response.status === 402) {
        return new Response(
          JSON.stringify({ error: "AI credits exhausted. Please add credits to continue." }),
          { status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      const errText = await response.text();
      console.error("AI gateway error:", response.status, errText);
      throw new Error(`AI gateway error: ${response.status}`);
    }

    const data = await response.json();
    const images = data.choices?.[0]?.message?.images || [];
    const text = data.choices?.[0]?.message?.content || "";

    // Extract base64 image URLs
    const resultImages = images.map((img: any) => img.image_url?.url).filter(Boolean);

    console.log(`Generated ${resultImages.length} images for ${feature}`);

    return new Response(
      JSON.stringify({
        success: true,
        images: resultImages,
        message: text,
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (e) {
    console.error("ai-generate error:", e);
    return new Response(
      JSON.stringify({ error: e instanceof Error ? e.message : "Unknown error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
